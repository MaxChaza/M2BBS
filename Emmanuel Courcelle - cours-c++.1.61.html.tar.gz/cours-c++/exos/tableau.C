//#include <cstdlib>
#include <iostream>
using namespace std;

class tableau {
public:

  // Le constructeur principal - on passe la dimension du tableau en parametre
  explicit tableau(int n): sz(n) {
    cerr << "constructeur sz = " << n << endl;
    A = (int *) malloc(sz*sizeof(int));
    copie(0,A,sz);
  };

  // Le constructeur de copie - on fait l'alloc de memoire puis on copie
  tableau (const tableau & t): sz(t.sz) {
    cerr << "constructeur de copie" << endl;
    A = (int *) malloc(sz*sizeof(int));
    copie(t.A,A,sz);
  };

  // L'operateur = PAS D'ALLOCATION DE MEMOIRE, c'est deja fait !!!
  tableau & operator=(const tableau &t) {
    cerr << "operateur =" << endl;
    if (this==&t)    // Pour gerer les cas A=A
      return *this;

    if (sz != t.sz) {
      cerr << "Ne peut pas egaliser deux tableaux de tailles differentes" << endl; 
    };
    copie(t.A,A,sz);
    return *this;
  };

  // Le destructeur: rendre la memoire au systeme
  ~tableau() { 
    cerr << "destructeur (sz = " << sz << ")\n";
    free(A);
  };

  // renvoie la taille du tableau
  int size() const { return sz;};

  // renvoie un element du tableau sans deborder
  int & operator[](int i) {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=sz) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[sz]\n";
      return *(A+sz-1);
    } else {
      return *(A+i);
    };
  };

  // meme chose - version const
  const int & operator[](int i) const {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=sz) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[sz]\n";
      return *(A+sz-1);
    } else {
      return *(A+i);
    };
  };

  // operateurs +=
  // Le parametre est un autre tableau
  tableau & operator+=(const tableau & t) {
    if (sz != t.sz) {
      cerr << "Ne peut pas ajouter deux tableaux de tailles differentes" << endl; 
    } else {
      for (int i=0; i < sz; i++) {
	A[i] += t[i];
      };
    };
    return *this;
  };

  // Le parametre est un entier
  tableau & operator+=(int x) {
    for (int i=0; i < sz; i++) {
      A[i] += x;
    };
    return *this;
  };

  // imprime le tableau sur la sortie standard
  void print () const  {
    for (int i=0; i < sz; i++) {
      cout << *(A+i) << " ";
    };
    cout << endl;
  }

private:
  const int sz;
  int *A;

  void copie (int src, int *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = src;
    };
  };
  void copie (int *src, int *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = *(src++);
    };
  }

};

tableau operator+(const tableau& t1, const tableau& t2) {
  tableau s(t1.size());
  if (t1.size() != t2.size()) {
    cerr << "Ne peut pas ajouter deux tableaux de tailles differentes" << endl; 
  } else {
    s = t1;
    s += t2;
  };
  return s;
};


main() {
  tableau T1(10);
  for (int i=0; i<10; i++) {
    T1[i]=10;
  };

  tableau T2 = T1;
  T1.print();
  T2.print();
  cout <<endl;
  T1 += T2;
  T1.print();
  T2.print();
  cout <<endl;
  tableau T3(10);
  T3 = T1 + T2;
  T1.print();
  T2.print();
  T3.print();
  cout <<endl;
}
