
#include <string>
#include <iostream>
#include "seqprot2.h"

using namespace std;

//
// operateurs + 
//

seqprot operator+ (const seqprot & s1, const seqprot & s2) {
  seqprot somme = s1;
  somme += s2;
  return somme;
};

seqadn operator+ (const seqadn & s1, const seqadn & s2) {
  seqadn somme = s1;
  somme += s2;
  return somme;
};

//
// operateurs << 
//

ostream & operator<< (ostream & os, const seqmac & s) {
  s.writeseq(os);
  return os;
};

//
// constructeurs = definitions
//

seqmac::seqmac(const string & seq, const string & name, const string & alphabet) : 
  _alph(alphabet), _name(name) {
  _seq="";
  for(string::const_iterator c = seq.begin();c != seq.end(); c++ ) {
    if (_alph.is_in_alpha(*c))
      _seq += *c;
  };
};

