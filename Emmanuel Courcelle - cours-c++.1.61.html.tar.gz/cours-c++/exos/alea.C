#include <iostream>
#include <cmath>
#include <ctime>
using namespace std;

int A[200];

void raz() {
   for(int i=0;i<200;i++) {
      A[i]=0;
   }
}

void imp() {
   for (int j=0;j<9;j++) {
      for (int i=0;i<20;i++) {
         cout << A[i+20*j] << ' ';
      };
      cout << "\n";
   }
}

int &alea() {
   int z;
   const int ech=32768;
   z=rand()*200/ech;
   return A[z];
}

main() {
   srand(time(NULL));
   raz();
   for(int i=0;i<200;i++) {
      alea() = i;
   }
   imp();
   cout << endl;
}

