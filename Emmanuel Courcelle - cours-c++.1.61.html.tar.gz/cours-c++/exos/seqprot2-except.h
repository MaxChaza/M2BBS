
#ifndef PC_SEQPROT_H
#define PC_SEQPROT_H

#include <set>
#include <string>
#include <iostream>
#include <stdexcept>

using namespace std;

typedef set<char> cs_type;

//
// alpha = un alphabet
// 
//         constructeur   = passer une chaine de caracteres
//                          On prend chaque lettre, si une lettre est dupliquee elle ne sera
//                          comptee qu'une fois.
//                          
//         is_in_alpha(c) renvoie true si c est dans l'alphabet
//                        false sinon
//         nb_of_elt renvoie le nombre de lettres de l'alphabet
//         

class alpha {
public:
  alpha(const string & s) {
    for(string::const_iterator c = s.begin();c != s.end(); c++ ) 
      _cs.insert(*c);
  };
  bool is_in_alpha(char c) const {return (_cs.find(c)!=_cs.end());};
  int nb_of_elt()       const {return _cs.size();};

private:
  cs_type _cs;
  int _nb;
};

//
// mac_except= une exception derivee de la classe exception standard 
// 

class mac_except: public range_error {
 public:
  mac_except(const string &s):range_error(""),_good_str(s) {};
  const char * what() const {return "Caracteres ne convenant pas pour cette sequence";};
  string good_str() {return _good_str;};
 private:
  string _good_str;
};

//
// seqmac    = une sequence de machins (proteiques ou nucleiques)
//
//           constructeur   = passer une chaine pour la seq, une chaine pour le nom,
//                            une chaine pour l'alphabet
//                            Les lettres ne faisant pas partie de l'alphabet sont ignorees
//
//           getseq renvoie la sequence
//           getname renvoie le nom
//           getseqlen renvoie le nombre de machins
//           +=, + permettent de concatener deux seqprot
//           operator<< ecrit la sequence en utilisant writeseq (fonction private)
//           writeseq est une fonction virtuelle pure.
//           

class seqmac {
public:
  seqmac (const string & seq, const string & name, const string & alphabet);
  string getseq()  const {return _seq;};
  string getname() const {return _name;};
  size_t getseqlen() const {return _seq.size();};
  friend ostream & operator<< (ostream &, const seqmac &);
  seqmac & operator=(const seqmac &s) {    // operator= par defaut pas utilisable
    _seq = s._seq;                         // a cause du membre constant _alph !!!
    _name= s._name;
    return *this;
  };
protected:
  string _seq;
  string _name;
  seqmac & operator+= (const seqmac & s) { // Si operator+= est public, la ligne P1 += A1 est possible
    _seq += s._seq;
    _name+= " " + s._name;
    return *this;
  };

private:
  const alpha _alph;
  //  void writeseq(ostream & os) const {os << "coucou\n";}; // operator<< imprimera coucou
  // virtual void writeseq(ostream & os) const {os << "coucou\n";}; // operator<< appellera la bonne fct
  virtual void writeseq(ostream &) const = 0;                     // autant mettre une fct virtuelle pure
};

//
// seqprot = une sequence proteique
//
//           Les machins sont des acides amines
//           writeseq est implementee
//
//           constructeur   = passer une chaine pour la seq, une chaine pour le nom
//                            seq est initialisee en prenant ACDEFGHIKLMNPQRSTV comme alphabet
//
//           += appelle l'operateur += de seq sur une sequence proteique seulement
//           Si on ne definit pas +=, la ligne ci-dessous P += A devient possible !!!
//           


class seqprot: public seqmac {
public:
  seqprot(const string & seq="", const string & name="") : seqmac(seq,name,"ACDEFGHIKLMNPQRSTV") {};
  seqprot & operator += (const seqprot &s) {
    this->seqmac::operator+=(s);
    return *this;
  };
private:
  void writeseq(ostream & os) const {
    os << "SEQUENCE PROTEIQUE\n" << "--------------\n";
    os << "Nom : " << _name << "\n";
    os << "Seq : " << _seq << "\n";
    os << "aa  : " << _seq.size() << "\n";
  };
};

//
// seqadn = une sequence d'adn
//
//          Les machins sont des acides nucleiques
//          writeseq est implementee
//
//          constructeur   = passer une chaine pour la seq, une chaine pour le nom
//                           seq est initialisee en prenant CGAT comme alphabet
//
//           +=, + permettent de concatener deux seqadn
//
//           Si on ne definit pas +=, la ligne ci-dessous P += A devient possible !!!
//           

class seqadn: public seqmac {
public:
  seqadn(const string & seq="", const string & name="") : seqmac(seq,name,"CGAT") {};
  seqadn & operator += (const seqadn &s) {
    this->seqmac::operator+=(s);          // forcer l'operateur de la classe de base
    return *this;
  };
  
private:
  void writeseq(ostream & os) const {
    os << "SEQUENCE NUCLEIQUE\n" << "--------------\n";
    os << "Nom : " << _name << "\n";
    os << "Seq : " << _seq << "\n";
    os << "an  : " << _seq.size() << "\n";
  };
};

//
// operateurs + 
//
// NOTE - Essayez d'ecrire un operator+ qui travaille avec seqmac.
//        ca ne marche pas - pourquoi ?
//        

seqprot operator+ (const seqprot &, const seqprot &); 
seqadn  operator+ (const seqadn  &, const seqadn &);

//
// operateur << 
//

ostream & operator<< (ostream &, const seqmac &);

#endif
