#include <fstream>
#include <iostream>
#include <memory>
using namespace std;

class error {};

class tableaukiplante {
    private:
    int * a;
    
    public:
    tableaukiplante() {
        cerr << "constructeur\n";
	a = new int[1000];	// Allocation d'un tableau de 1 Mo !!!
	error e;
	throw(e);
    };
    ~tableaukiplante() {
        cerr << "destructeur\n";
	delete a;
	a=NULL;
    };
};

typedef auto_ptr<int> int_ptr;
class tableaukimarche {
    private:
    auto_ptr<int> a;
    
    public:
    tableaukimarche() {
        cerr << "constructeur\n";
	const auto_ptr<int>b(new int[1000000]);	// ATTENTION la ligne a=b ne compilera pas !!!
	//int_ptr b(new int[1000]);
	a=b;		// PAS d'operator= depuis int *, mais OK car a devient proprietaire
	error e;
	throw(e);
    };
    ~tableaukimarche() {
        cerr << "destructeur\n";
    };

};

main() {

    for (;;) {	// Cette boucle n'est pas infinie car ca plante au bout de qq iterations
	try {
	    tableaukiplante f;
	} catch(const error &e) {
	    cerr << "error\n";
	};
    };

    for (;;) {		// Cette boucle est infinie car il n'y a pas de fuite de memoire
	try {
	    tableaukimarche f;
	} catch(const error &e) {
	    cerr << "error\n";
	};
    };
};

