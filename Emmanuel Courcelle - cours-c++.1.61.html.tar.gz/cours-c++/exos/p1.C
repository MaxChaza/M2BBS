
#include <iostream>
using namespace std;

int A[10];

void remplitA() {
   for (int i=0; i<=9;i++) {
	A[i] = i;
   };
};

void impA() {
   for (int i=0; i<=9; i++) {
        cout << "A[" << i << "] = " << A[i] << "\n";
   };
   cout <<  "\n";
}

main() {
   remplitA();
   
   impA();

   int &b = A[5];
   b++;  
   impA();

   int * c= A+7;
   (*c)++;
   *c++, (*c)++;
   impA();

   cout << "b = " << b << " adr de b = " << &b << "\n";
   cout << "c = " << c << " adr de c = " << &c << " val de *c = " << *c << "\n";
}

