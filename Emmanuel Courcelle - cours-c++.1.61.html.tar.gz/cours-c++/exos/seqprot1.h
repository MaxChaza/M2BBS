
#ifndef PC_SEQPROT_H
#define PC_SEQPROT_H

#include <set>
#include <string>
#include <iostream>
using namespace std;

typedef set<char> cs_type;

//
// alpha = un alphabet
// 
//         constructeur   = passer une chaine de caracteres
//                          On prend chaque lettre, si une lettre est dupliquee elle ne sera
//                          comptee qu'une fois.
//                          
//         is_in_alpha(c) renvoie true si c est dans l'alphabet
//                        false sinon
//         nb_of_elt renvoie le nombre de lettres de l'alphabet
//         

class alpha {
public:
  alpha(const string & s) {
    for(string::const_iterator c = s.begin();c != s.end(); c++ ) 
      _cs.insert(*c);
  };
  bool is_in_alpha(char c) const {return (_cs.find(c)!=_cs.end());};
  int nb_of_elt()       const {return _cs.size();};

private:
  cs_type _cs;
  int _nb;
};

//
// seqprot = une sequence proteique
//
//           constructeur   = passer une chaine pour la seq, une chaine pour le nom
//                            Les lettres differentes de ACDEFGHIKLMNPQRSTV sont ignorees
//
//           getseq renvoie la sequence
//           getname renvoie le nom
//           getseqlen renvoiele nombre d'aa
//           +=, + permettent de concatener deux seqprot
//           operator<< ecrit la sequence en utilisant writeseq (fonction private)
//           

class seqprot {
public:
  seqprot(const string & seq, const string & name);
  string getseq()  const {return _seq;};
  string getname() const {return _name;};
  size_t getseqlen() const {return _seq.size();};
  seqprot & operator+= (const seqprot & s) { 
    _seq += s._seq;
    _name+= " " + s._name;
    return *this;
  };
  friend ostream & operator<< (ostream &, const seqprot &);

private:
  const alpha _alph;
  string _seq;
  string _name;
  void writeseq(ostream & os) const {
    os << "SEQUENCE PROTEIQUE\n" << "--------------\n";
    os << "Nom : " << _name << "\n";
    os << "Seq : " << _seq << "\n";
    os << "aa  : " << _seq.size() << "\n";
  };
};

//
// seqadn = une sequence d'adn
//
//           constructeur   = passer une chaine pour la seq, une chaine pour le nom
//                            Les lettres differentes de CGAT sont ignorees
//
//           getseq renvoie la sequence
//           getname renvoie le nom
//           getseqlen renvoie le nombre d'an
//           +=, + permettent de concatener deux seqprot
//           operator<< ecrit la sequence en utilisant writeseq (fonction private)
//           

class seqadn {
public:
  seqadn(const string & seq, const string & name);
  string getseq()  const {return _seq;};
  string getname() const {return _name;};
  size_t getseqlen() const {return _seq.size();};
  seqadn & operator+= (const seqadn & s) { 
    _seq += s._seq;
    _name+= " " + s._name;
    return *this;
  };
  friend ostream & operator<< (ostream &, const seqadn &);
  
private:
  const alpha _alph;
  string _seq;
  string _name;
  void writeseq(ostream & os) const {
    os << "SEQUENCE D'ADN\n" << "--------------\n";
    os << "Nom : " << _name << "\n";
    os << "Seq : " << _seq << "\n";
    os << "an  : " << _seq.size() << "\n";
  };
};

//
// operateurs + 
//

seqprot operator+ (const seqprot &, const seqprot &); 
seqadn  operator+ (const seqadn  &, const seqadn &);

//
// operateurs << 
//

ostream & operator<< (ostream &, const seqprot &);
ostream & operator<< (ostream &, const seqadn &);

#endif
