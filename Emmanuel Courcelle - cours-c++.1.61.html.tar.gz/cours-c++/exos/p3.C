#include <iostream>
using namespace std;

int A[10];

void remplitA() {
   for (int i=0; i<=9;i++) {
	A[i] = i;
   };
};

void impA() {
   for (int i=0; i<=9; i++) {
        cout << "A[" << i << "] = " << A[i] << "\n";
   };
   cout <<  "\n";
}

main() {
  const int * a       = A+5;
  int * const b       = A+5;
  const int * const c = A+5;
  int * d             = A+5;

  //  *a = 10;                        // Erreur !!!
  cout << "*a = " << *a << endl;
  remplitA();
  cout << "*a = " << *a << endl;
  a++;
  cout << "*a = " << *a << endl;

  cout << "*b = " << *b << endl;
  //  b++;				// Erreur !!
  *b=100;
  cout << "*b = " << *b << endl;

  cout << "*c = " << *c << endl;
  remplitA();
  //  *c = 0;			// Erreur !!
  //  c++;				// Erreur !!
  cout << "*c = " << *c << endl;

  cout << "*d = " << *d << endl;
  remplitA();
  *d = 0;
  d++;	   
  cout << "*d = " << *d << endl;


}

