#include <iostream>
#include <string>

#include "seqprot2-except.h"
#include "seqarn.h"


/******************************************
  P R O G R A M M E     P R I N C I P A L

compiler avec g++ seqprot2-except.C seqarn.C seqarn-main-except.C

*******************************************/

main() {
  string s1,s2,s3;

  seqprot P;
  cout << "Entrez une sequence proteique: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  try {
    seqprot P1(s1,s2);
    P=P1;
  } catch(mac_except & e) {
    cout << "PB " << e.what() << "\n";
    cout << "vous pourriez essayer " << e.good_str() << "\n";
    exit(0);
  };

  seqadn A;
  cout << "Entrez une sequence d'adn: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  try {
    seqadn A1(s1,s2);
    A=A1;
  } catch (mac_except & e) {
    seqadn A1(e.good_str(),s2);
    A=A1;
  };
    
  cout << "Entrez une sequence d'arn: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  seqarn R(s1,s2);
  
  P += P;
  //  P += A;                          // NE DOIT PAS COMPILER !!!

  //  seqmac & P1=P;
  //  seqmac & A1=A;
  //  P1 += A1;                        // NE DOIT PAS COMPILER !!!

  cout << P << A << "\n";
  cout << P + P << A + A + A << "\n";
  cout << R + R + R << "\n";
    //  cout << P + A << "\n";         // NE DOIT PAS COMPILER !!!

};
