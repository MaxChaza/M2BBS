
#ifndef PC_SEQARN_H
#define PC_SEQARN_H

#include <string>
#include <iostream>
#include "seqprot2.h"
using namespace std;

//
// seqarn = une sequence proteique
//
//           Les machins sont des acides nucleiques (ACGU)
//           writeseq est implementee
//
//           constructeur   = passer une chaine pour la seq, une chaine pour le nom
//                            seq est initialisee en prenant ACGU comme alphabet
//
//           += appelle l'operateur += de seq sur une sequence proteique seulement
//           Si on ne definit pas +=, la ligne ci-dessous P += A devient possible !!!
//           


class seqarn: public seqmac {
public:
  seqarn(const string & seq="", const string & name="") : seqmac(seq,name,"ACGU") {};
  seqarn & operator += (const seqarn &s) {
    this->seqmac::operator+=(s);
    return *this;
  };
private:
  void writeseq(ostream & os) const {
    os << "SEQUENCE D'ARN\n" << "--------------\n";
    os << "Nom : " << _name << "\n";
    os << "Seq : " << _seq << "\n";
    os << "aa  : " << _seq.size() << "\n";
  };
};

//
// operateur + 
//

seqarn  operator+ (const seqarn  &, const seqarn &);

#endif
