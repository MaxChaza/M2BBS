
#include <iostream>
using namespace std;

// Un objet-fonction de base

template <class T=int> class ofct_base {
public:
  virtual T operator()(T) const = 0;
};

template<class T=int> class tableau {
public:

  // Le constructeur principal - on passe la dimension du tableau en parametre
  explicit tableau(int n): sz(n) {
    cerr << "constructeur sz = " << n << endl;
    A = (T *) malloc(sz*sizeof(T));
    copie((T)0,A,sz);	// Le (T) est important pour level une ambiguite
  };

  // Le constructeur de copie - on fait l'alloc de memoire puis on copie
  tableau (const tableau & t): sz(t.sz) {
    cerr << "constructeur de copie" << endl;
    A = (T *) malloc(sz*sizeof(T));
    copie(t.A,A,sz);
  };

  // L'operateur = PAS D'ALLOCATION DE MEMOIRE, c'est deja fait !!!
  tableau & operator=(const tableau &t) {
    cerr << "operateur =" << endl;
    if (this==&t)    // Pour gerer les cas A=A
      return *this;

    if (sz != t.sz) {
      cerr << "Ne peut pas egaliser deux tableaux de tailles differentes" << endl; 
    };
    copie(t.A,A,sz);
    return *this;
  };

  // Le destructeur: rendre la memoire au systeme
  ~tableau() { 
    cerr << "destructeur (sz = " << sz << ")\n";
    free(A);
  };

  // renvoie la taille du tableau
  int size() const { return sz;};

  // renvoie un element du tableau sans deborder
  T & operator[](int i) {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=sz) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[sz]\n";
      return *(A+sz-1);
    } else {
      return *(A+i);
    };
  };

  // meme chose - version const
  const T & operator[](int i) const {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=sz) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[sz]\n";
      return *(A+sz-1);
    } else {
      return *(A+i);
    };
  };

  // operateurs +=
  // Le parametre est un autre tableau
  tableau & operator+=(const tableau & t) {
    if (sz != t.sz) {
      cerr << "Ne peut pas ajouter deux tableaux de tailles differentes" << endl; 
    } else {
      for (int i=0; i < sz; i++) {
	A[i] += t[i];
      };
    };
    return *this;
  };

  // Le parametre est un entier
  tableau & operator+=(T x) {
    for (int i=0; i < sz; i++) {
      A[i] += x;
    };
    return *this;
  };

  // imprime le tableau sur la sortie standard
  void print () const  {
    for (int i=0; i < sz; i++) {
      cout << *(A+i) << " ";
    };
    cout << endl;
  }

  // La fonction transform: on lui passe un objet-fonction
  void transform(const ofct_base<T> & f) {
    for (int i=0; i< sz; i++) 
      A[i]=f(A[i]);
  };
  

private:
  const int sz;
  T *A;

  void copie (T src, T *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = src;
    };
  };
  void copie (T *src, T *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = *(src++);
    };
  }

};

template <class T> tableau<T> operator+(const tableau<T>& t1, const tableau<T>& t2) {
  tableau<T> s(t1.size());
  if (t1.size() != t2.size()) {
    cerr << "Ne peut pas ajouter deux tableaux de tailles differentes" << endl; 
  } else {
    s = t1;
    s += t2;
  };
  return s;
};

// ===========================================================
// ATTENTION !!! Contrairement tableau3-ofct.C, on ne peut pas
//               definir ces templates a l'interieur de main.
//               Obligatoire de les definir au niveau global
//

template <class T=int> class fois2: public ofct_base<T> {
public:
  T operator()(T x) const {return 2*x;};
};
  

template <class T=int>  class seuil: public ofct_base<T> {
public:
  explicit seuil(T s)  : __s (s){};
  T operator()(T x) const {return x < __s ? x : __s;};
private:
  T __s;
};
// ===========================================================

main() {
  tableau<float> T1(10);

  for (int i=0; i<10; i++) {
    T1[i]=i*10 + 0.1;
  };


  seuil<float> f(35);
  fois2<float> g;
  /*seuil<> f(35);		NE COMPILE PAS
  fois2<> g;*/
  T1.print();
  T1.transform(f);
  T1.print();
  T1.transform(g);
  T1.print();
};
