
#include <iostream>
using namespace std;

// Un objet-fonction de base

template <class T> class ofct_base {
public:
  virtual T operator()(T) const = 0;
};

template<class T=int, int SIZE=10> class tableau {
public:

  // Le constructeur par defaut - Pas besoin de passser la taille en parametre, c'est un modele
  tableau() {
    cerr << "constructeur SIZE = " << SIZE << endl;
    A = (T *) malloc(SIZE*sizeof(T));
    copie((T) 0,A,SIZE);
  };

  // Le constructeur de copie - on fait l'alloc de memoire puis on copie
  tableau (const tableau & t) {
    cerr << "constructeur de copie" << endl;
    A = (T *) malloc(SIZE*sizeof(T));
    copie(t.A,A,SIZE);
  };

  // L'operateur = PAS D'ALLOCATION DE MEMOIRE, c'est deja fait !!!
  // Le systeme lui-meme assure qu'on n'a pas de pb avec les tailles
  tableau  & operator=(const tableau &t) {
    cerr << "operateur =" << endl;
    if (this==&t)    // Pour gerer les cas A=A
      return *this;

    copie(t.A,SIZE);
    return *this;
  };

  // Le destructeur: rendre la memoire au systeme
  ~tableau() { 
    cerr << "destructeur (SIZE = " << SIZE << ")\n";
    free(A);
  };

  // renvoie la taille du tableau (mais ca ne sert a rien ici)
  int size() const { return SIZE;};

  // renvoie un element du tableau sans deborder
  T & operator[](int i) {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=SIZE) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[SIZE-1]\n";
      return *(A+SIZE-1);
    } else {
      return *(A+i);
    };
  };

  // meme chose - version const
  const T & operator[](int i) const {
    if (i<0) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[0]\n";
      return *A;
    } else if (i>=SIZE) {
      cerr << "ATTENTION Debordement de tableau - je renvoie tableau[SIZE-1]\n";
      return *(A+SIZE-1);
    } else {
      return *(A+i);
    };
  };

  // operateurs +=
  // Le parametre est un autre tableau
  // Le systeme lui-meme assure qu'on n'a pas de pb avec les tailles

  tableau & operator+=(const tableau & t) {
    for (int i=0; i < SIZE; i++) {
      A[i] += t[i];
    };
    
    return *this;
  };

  // Le parametre est un entier
  tableau & operator+=(T x) {
    for (int i=0; i < SIZE; i++) {
      A[i] += x;
    };
    return *this;
  };

  // imprime le tableau sur la sortie standard
  void print () const  {
    for (int i=0; i < SIZE; i++) {
      cout << *(A+i) << " ";
    };
    cout << endl;
  }

  // La fonction transform: on lui passe un objet-fonction
  void transform(const ofct_base<T> & f) {
    for (int i=0; i< SIZE; i++) 
      A[i]=f(A[i]);
  };
  

private:
  T *A;

  void copie (T src, T *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = src;
    };
  };
  void copie (T *src, T *dest, int s) {
    for (int i=0; i<s; i++) {
      *(dest++) = *(src++);
    };
  }

};

template <class T, int SIZE> tableau<T,SIZE> operator+(const tableau<T,SIZE>& t1, const tableau<T,SIZE>& t2) {
  tableau<T,SIZE> s(t1.size());
  if (t1.size() != t2.size()) {
    cerr << "Ne peut pas ajouter deux tableaux de tailles differentes" << endl; 
  } else {
    s = t1;
    s += t2;
  };
  return s;
};

// ===========================================================
// ATTENTION !!! Contrairement a tableau3-ofct.C, on ne peut pas
//               definir ces templates a l'interieur de main.
//               Obligatoire de les definir au niveau global
//

template <class T=int> class fois2: public ofct_base<T> {
public:
  T operator()(T x) const {return 2*x;};
};
  

template <class T=int>  class seuil: public ofct_base<T> {
public:
  seuil(T s)  : __s (s){};
  T operator()(T x) const {return x < __s ? x : __s;};
private:
  T __s;
};
// ===========================================================

main() {
  tableau<float> T1;

  for (int i=0; i<10; i++) {
    T1[i]=i*10+0.1;
  };


 /* seuil<> f=35;			NE COMPILE PAS !!!
  fois2<> g; */
  seuil<float> f=35;
  fois2<float> g;

  T1.print();
  T1.transform(f);
  T1.print();
  T1.transform(g);
  T1.print();
};
