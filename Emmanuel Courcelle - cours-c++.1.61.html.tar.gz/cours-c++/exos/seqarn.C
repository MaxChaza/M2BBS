
#include <string>
#include <iostream>
#include "seqprot2.h"
#include "seqarn.h"

using namespace std;

//
// operateur + 
//

seqarn operator+ (const seqarn & s1, const seqarn & s2) {
  seqarn somme = s1;
  somme += s2;
  return somme;
};

