#include <iostream>
#include <string>

#include "seqprot2.h"
#include "seqarn.h"


/******************************************
  P R O G R A M M E     P R I N C I P A L

compiler avec g++ seqprot2.C seqarn.C seqarn-main.C

*******************************************/

main() {
  string s1,s2,s3;

  cout << "Entrez une sequence proteique: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  seqprot P(s1,s2);

  cout << "Entrez une sequence d'adn: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  seqadn A(s1,s2);

  cout << "Entrez une sequence d'arn: ";
  cin >> s1;
  cout << "Entrez son nom: ";
  cin >> s2;
  seqarn R(s1,s2);

  P += P;
  //  P += A;                          // NE DOIT PAS COMPILER !!!

  //  seqmac & P1=P;
  //  seqmac & A1=A;
  //  P1 += A1;                        // NE DOIT PAS COMPILER !!!

  cout << P << A << "\n";
  cout << P + P << A + A + A << "\n";
  cout << R + R + R << "\n";
    //  cout << P + A << "\n";         // NE DOIT PAS COMPILER !!!
};
