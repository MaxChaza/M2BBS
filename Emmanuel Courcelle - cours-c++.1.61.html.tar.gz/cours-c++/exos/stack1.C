#include <iostream>
using namespace std;


class stack { 
public:
  stack(int n) : size(n), top(0) {
    if (debflg) {
      cout << "Ici constructeur de stack size = " << size << "\n";
    };
    A = (int *) malloc(size*sizeof(int));
    for (int i=0; i<size; i++) A[i] = 0;
  };
  ~stack() { 
    free(A); 
    if (debflg) {
      cout << "Ici destructeur de stack (size = " << size << ")\n";
    };
  };
  static void set_deb () { debflg=true;};
  static void clr_deb () { debflg=false;};
  void push (int);
  int pop();
  int length() const {return top;};

private:
  const int size;
  int *A;
  int top;
  static bool debflg;

};

void stack::push (int i) {
  if (top < size) {
    A[top++] = i;
  }
}

int stack::pop() {
  if (top) {
    return A[--top];
  } else {
    return 0;
  }
}

bool stack::debflg=false;

int main() {
  stack::set_deb();	// je veux voir ce qui se passe
  stack s(10);
  s.push(10);
  s.push(9);
  s.push(8);
  s.push(7);
  s.push(6);
  s.push(5);
  s.push(4);
  s.push(3);
  s.push(2);
  s.push(1);
  
  for (int i=0; i<15; i++) {
    cout << s.length() << "  " << s.pop() << "\n";
  }
  {
    stack j(5);    // on construit une nouvelle pile
    j.push(4);
    j.push(2);     // on joue avec
  };               // Elle disparait
  stack::clr_deb();	// Je ne veux plus voir ce qui se passe
}

   
