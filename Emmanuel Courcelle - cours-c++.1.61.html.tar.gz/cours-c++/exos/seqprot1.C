
#include <string>
#include <iostream>
#include "seqprot1.h"

using namespace std;

//
// operateurs + 
//

seqprot operator+ (const seqprot & s1, const seqprot & s2) {
  seqprot somme = s1;
  somme += s2;
  return somme;
};

seqadn operator+ (const seqadn & s1, const seqadn & s2) {
  seqadn somme = s1;
  somme += s2;
  return somme;
};

//
// operateurs << 
//

ostream & operator<< (ostream & os, const seqprot & s) {
  s.writeseq(os);
  return os;
};

ostream & operator<< (ostream & os, const seqadn & s) {
  s.writeseq(os);
  return os;
};

//
// constructeurs = definitions
//

seqprot::seqprot(const string & seq, const string & name) : 
  _alph("ACDEFGHIKLMNPQRSTV"), _name(name) {
  _seq="";
  for(string::const_iterator c = seq.begin();c != seq.end(); c++ ) {
    if (_alph.is_in_alpha(*c))
      _seq += *c;
  };
};

seqadn::seqadn(const string & seq, const string & name) : 
  _alph("GCAT"), _name(name) {
  _seq="";
  for(string::const_iterator c = seq.begin();c != seq.end(); c++ ) {
    if (_alph.is_in_alpha(*c))
      _seq += *c;
  };
};

