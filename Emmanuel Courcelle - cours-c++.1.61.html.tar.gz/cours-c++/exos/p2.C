#include <iostream>
using namespace std;

main() {
   int A=10;
   int &b = A;
   int *c = &A;

   cout << "b = " << b << " adr de b = " << &b << "\n";
   cout << "c = " << c << " adr de c = " << &c << " val de *c = " << *c << "\n";

}

