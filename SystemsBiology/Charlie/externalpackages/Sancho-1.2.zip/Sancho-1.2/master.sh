if [ $# -lt 2 ]
then
	echo "$0 : Please provide the master host and the master JAR"
	exit 1
fi

echo "Starting master on $1..."
sudo java -cp . -Djava.rmi.server.codebase=http://$1/$2 -Djava.rmi.server.hostname=$1 -Djava.security.policy=master.policy -jar $2
