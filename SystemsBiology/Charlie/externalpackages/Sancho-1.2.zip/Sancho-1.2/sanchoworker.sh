if [ $# -eq 0 ]
then
	echo "$0 : Please provide the master host"
	exit 1
fi

echo "Starting worker on $1..."

java -cp . -Djava.rmi.server.codebase=http://$1 -Djava.security.policy=sanchoworker.policy -jar SanchoWorker.jar --rmiMaster $1
