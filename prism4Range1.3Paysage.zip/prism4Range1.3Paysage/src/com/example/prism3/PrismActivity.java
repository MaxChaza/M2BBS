package com.example.prism3;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TimeZone;
import java.util.UUID;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ConfigurationInfo;
import android.content.res.Resources;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.prism3.utils.SphereModel;
import com.example.prism3.utils.XMLBuilder;

// Activity which manages 3D application 
public class PrismActivity extends Activity implements OnClickListener,
		android.content.DialogInterface.OnClickListener {

	// Parameters of PrismActivity
	private static Integer nbSpheres;
	private static Integer nbDivisions;
	private static Float tailleSpheres;
	private static String typeSelection;
	private static String participant;
	private static String serie;
	private static boolean showTopView;
	private static boolean touchValidationIsChecked;
	/** Hold a reference to our GLSurfaceView */
	private PrismGLSurfaceView mGLSurfaceView;

	/** Hold a reference to our PrismRenderer */
	private PrismRenderer mRenderer;

	// Informations of device
	private DisplayMetrics displayMetrics;

	// Logs
	private Integer nbDivisionsScrollable;
	private Integer zoneEnCours = 0;
	private Integer touchCount;
	private float starting_distance;
	private boolean cibleTouchee;
	private boolean slideTouchee;
	private int nbClickRecherche = 0;

	private ArrayList<ArrayList<HashMap>> listTask = new ArrayList<ArrayList<HashMap>>();
	private ArrayList<HashMap<String, String>> listLogs = new ArrayList<HashMap<String, String>>();

	private HashMap hashBuff = new HashMap<>();

	// // Buttons to select the target
	// private boolean frontIsSelectable;
	// private boolean backIsSelectable;
	// private boolean undoIsSelectable;

	// Dialog frame
	private View buttonFront;
	private View buttonBack;
	private View buttonUndo;
	private View buttonValidate;
	private int buttonWidth;

	private AlertDialog.Builder builder;
	private AlertDialog dialog;

	private XMLBuilder xmlLogs;
	private int screen_width;
	private int screen_heights;
	private int actionBarHeight;
	private int navigationBarHeight;
	private int statusBarHeight;
	private boolean firstTouch = true;
	private static final UUID MY_UUID = UUID
			.fromString("00001101-0000-1000-8000-00805F9B34FB");

	private static final int REQUEST_DISCOVERABLE_BT = 0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Layout deserialisation
		setContentView(R.layout.activity_prism);

		displayMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
		Display display = getWindowManager().getDefaultDisplay();

		/** On r�cupere la taille des diff�rents composants du device */
		TypedValue tv = new TypedValue();
		getApplicationContext().getTheme().resolveAttribute(
				android.R.attr.actionBarSize, tv, true);
		actionBarHeight = getResources().getDimensionPixelSize(tv.resourceId);

		Resources resources = getApplicationContext().getResources();
		navigationBarHeight = resources.getIdentifier("navigation_bar_height",
				"dimen", "android");
		navigationBarHeight = resources
				.getDimensionPixelSize(navigationBarHeight);

		resources = getApplicationContext().getResources();
		statusBarHeight = resources.getIdentifier("status_bar_height", "dimen",
				"android");
		statusBarHeight = resources.getDimensionPixelSize(statusBarHeight);

		screen_width = display.getWidth() / 2; // to be used later for
												// navigation with touch
												// screen
		screen_heights = display.getHeight() / 2;

		slideTouchee = false;

		// Parameters recovery
		nbSpheres = getIntent().getIntExtra("nbSpheres", 1);
		nbDivisions = getIntent().getIntExtra("nbDivisions", 1);
		tailleSpheres = getIntent().getFloatExtra("tailleSpheres", 0.04f);
		typeSelection = getIntent().getStringExtra("typeSelection");
		participant = getIntent().getStringExtra("participant");
		serie = getIntent().getStringExtra("serie");
		showTopView = getIntent().getBooleanExtra("topViewIsChecked", false);
		touchValidationIsChecked = getIntent().getBooleanExtra(
				"touchValidationIsChecked", false);

		/**
		 * Get all objects on layout
		 */
		LinearLayout buttonLayout = (LinearLayout) findViewById(R.id.buttonLayout);
		buttonWidth = (int) ((1.25f * screen_width * 2) / 5.5f);
		buttonLayout.setPadding(0, 0, (screen_width * 2) - buttonWidth, 0);

		buttonUndo = (Button) findViewById(R.id.buttonUndo);
		buttonUndo.setOnClickListener(this);

		buttonBack = (Button) findViewById(R.id.buttonBack);
		buttonBack.setOnClickListener(this);

		buttonFront = (Button) findViewById(R.id.buttonFront);
		buttonFront.setOnClickListener(this);

		buttonValidate = (Button) findViewById(R.id.buttonValidate);
		buttonValidate.setOnClickListener(this);
		initButton();

		builder = new AlertDialog.Builder(this);
		builder.setMessage(R.string.dialog_message).setTitle(
				R.string.dialog_title);
		builder.setPositiveButton("OK", this);
		dialog = builder.create();

		mGLSurfaceView = (PrismGLSurfaceView) findViewById(R.id.gl_surface_view);

		Integer vueAeriene = 0;
		if (showTopView)
			vueAeriene = 1;
		else
			vueAeriene = 0;

		Integer validationTouch = 0;
		if (touchValidationIsChecked)
			validationTouch = 1;
		else
			validationTouch = 0;

		xmlLogs = new XMLBuilder(getApplicationContext(), nbSpheres,
				nbDivisions, tailleSpheres, typeSelection, participant, serie,
				vueAeriene, validationTouch );

		// Check if the system supports OpenGL ES 2.0.
		final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		final ConfigurationInfo configurationInfo = activityManager
				.getDeviceConfigurationInfo();
		final boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;

		if (supportsEs2) {
			// Request an OpenGL ES 2.0 compatible context.
			mGLSurfaceView.setEGLContextClientVersion(2);

			// Set the renderer to our renderer, defined below.
			mRenderer = new PrismRenderer(this, nbSpheres, nbDivisions,
					tailleSpheres);
			mRenderer.setTypeSelection(typeSelection);

			mGLSurfaceView.setRenderer(mRenderer, displayMetrics.density);
			mGLSurfaceView.setRenderMode(mGLSurfaceView.RENDERMODE_WHEN_DIRTY);

		} else {
			// This is where you could create an OpenGL ES 1.x compatible
			// renderer if you wanted to support both ES 1 and ES 2.
			return;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean onTouchEvent(MotionEvent me) {
		if (firstTouch) {
			/** Log : Initialisation de la tache */
			hashBuff = new HashMap<String, String>();
			hashBuff.put("name", "Task");
			hashBuff.put("target", mRenderer.getCibleCoords().getId()
					.toString());
			hashBuff.put("t",
					((Long) Calendar.getInstance(TimeZone.getTimeZone("UTC"))
							.getTimeInMillis()).toString());
			listLogs.add(hashBuff);
			firstTouch = false;
		}
		if (mRenderer.isCreated()) {
			touchCount = me.getPointerCount();
			if (mRenderer.getCylindre().isVisible()) {
				if (me.getAction() == MotionEvent.ACTION_DOWN) {

					mRenderer.getCylindre().setCreated(true);

					/** On place le <code>Cylinder</code>. */
					mRenderer
							.setCylinder((Float) me.getX(), (Float) me.getY(),
									mRenderer.getCylindre().getRadius(),
									displayMetrics);

					/**
					 * Log : Enum�ration de toutes les <code>Sphere</code>s.
					 */
					hashBuff = new HashMap<>();
					hashBuff.put("name", "ListOfSphere");

					ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
					HashMap<String, String> hashSpheres;
					for (Sphere sphere : mRenderer.getListLogSpheres()) {
						hashSpheres = new HashMap<String, String>();
						hashSpheres.put("name", "Sphere");
						hashSpheres.put("id", sphere.getId().toString());
						hashSpheres.put("x", sphere.getX().toString());
						hashSpheres.put("y", sphere.getY().toString());
						hashSpheres.put("z", sphere.getZ().toString());
						listSpheres.add(hashSpheres);
					}
					hashBuff.put("spheres", listSpheres);
					listLogs.add(hashBuff);

					/** Log : Pression d'un doigt sur l'�cran */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "1");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					/** Log : Initialisation du <code>Cylinder</code> */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "CylinderEvent");
					hashBuff.put("type", "1");
					hashBuff.put("x",
							((Float) mRenderer.getCylindre().getX()).toString());
					hashBuff.put("y",
							((Float) mRenderer.getCylindre().getY()).toString());
					hashBuff.put("radius", ((Float) mRenderer.getCylindre()
							.getRadius()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}

				if (me.getAction() == MotionEvent.ACTION_MOVE
						&& touchCount == 1) {
					float xpos = me.getX();
					float ypos = me.getY();

					/** On d�place le <code>Cylinder</code>. */
					mRenderer.setCylinder(xpos, ypos, mRenderer.getCylindre()
							.getRadius(), displayMetrics);

					/** Mise � jour de l'affichage. */
					mGLSurfaceView.requestRender();

					/**
					 * Cr�ation de deux listes de <code>Sphere</code>s,
					 * permettant de savoir lesquelles viennent d'�tre
					 * s�lectionnes ou d�s�lectionn�es.
					 */
					HashSet<Sphere> listSphereAdded = new HashSet<>();
					HashSet<Sphere> listSphereRemoved = new HashSet<>();
					boolean cibleIsTouchedBeforeMoved = mRenderer
							.isCibleIsTouch();

					if (!mRenderer.getListCollisions().isEmpty()) {
						listSphereRemoved.addAll(mRenderer.getListCollisions());
					}

					mRenderer
							.setListCollisions(mRenderer.getCylindre()
									.collateCylinder(
											(HashSet<Sphere>) mRenderer
													.getListCoords()));

					if (!mRenderer.getListCollisions().isEmpty()) {
						listSphereAdded.addAll(mRenderer.getListCollisions());
						listSphereAdded.removeAll(listSphereRemoved);
						listSphereRemoved.removeAll(mRenderer
								.getListCollisions());
					}
					mRenderer.setCibleIsTouch(mRenderer.getCylindre()
							.isCollateCylinderAndCible(
									mRenderer.getCibleCoords()));

					if (cibleIsTouchedBeforeMoved
							&& !mRenderer.isCibleIsTouch())
						listSphereRemoved.add(mRenderer.getCibleCoords());

					if (!cibleIsTouchedBeforeMoved
							&& mRenderer.isCibleIsTouch())
						listSphereAdded.add(mRenderer.getCibleCoords());

					/**
					 * Log : Entr�e d'une <code>Sphere</code> dans le
					 * <code>Cylinder</code>.
					 */
					for (Sphere s : listSphereAdded) {
						hashBuff = new HashMap<String, String>();
						hashBuff.put("name", "SphereEvent");
						hashBuff.put("type", "1");
						hashBuff.put("id", ((Integer) s.getId()).toString());
						hashBuff.put(
								"t",
								((Long) Calendar.getInstance(
										TimeZone.getTimeZone("UTC"))
										.getTimeInMillis()).toString());
						listLogs.add(hashBuff);
					}

					/**
					 * Log : Sortie d'une <code>Sphere</code> du le
					 * <code>Cylinder</code>.
					 */
					for (Sphere s : listSphereRemoved) {
						hashBuff = new HashMap<String, String>();
						hashBuff.put("name", "SphereEvent");
						hashBuff.put("type", "0");
						hashBuff.put("id", ((Integer) s.getId()).toString());
						hashBuff.put(
								"t",
								((Long) Calendar.getInstance(
										TimeZone.getTimeZone("UTC"))
										.getTimeInMillis()).toString());
						listLogs.add(hashBuff);
					}

					/**
					 * Si la cible est touch�e on lance le son d'une
					 * notification du device.
					 */
					if (mRenderer.isCibleIsTouch()) {

						if (!slideTouchee) {
							Uri notification = RingtoneManager

							.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
							Ringtone r = RingtoneManager.getRingtone(
									getApplicationContext(), notification);
							r.play();

							cibleTouchee = true;
							slideTouchee = true;
						}
					} else {

						cibleTouchee = false;
						slideTouchee = false;
					}

					/** Log : D�placement sur l'�cran */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "2");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					/** Log : D�placement du <code>Cylinder</code>. */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "CylinderEvent");
					hashBuff.put("type", "2");
					hashBuff.put("x",
							((Float) mRenderer.getCylindre().getX()).toString());
					hashBuff.put("y",
							((Float) mRenderer.getCylindre().getY()).toString());
					hashBuff.put("radius", ((Float) mRenderer.getCylindre()
							.getRadius()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}

				if (me.getAction() == MotionEvent.ACTION_UP && touchCount == 1) {
					nbClickRecherche++;

					/** Log : Validation du <code>Cylinder</code>. */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "CylinderEvent");
					hashBuff.put("type", "4");
					hashBuff.put("x",
							((Float) mRenderer.getCylindre().getX()).toString());
					hashBuff.put("y",
							((Float) mRenderer.getCylindre().getY()).toString());
					hashBuff.put("radius", ((Float) mRenderer.getCylindre()
							.getRadius()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					/** Log : Lev�e du doigt de l'�cran. */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "3");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					mRenderer
							.setListCollisions(mRenderer.getCylindre()
									.collateCylinder(
											(HashSet<Sphere>) mRenderer
													.getListCoords()));
					mRenderer.setCibleIsTouch(mRenderer.getCylindre()
							.isCollateCylinderAndCible(
									mRenderer.getCibleCoords()));

					mRenderer.getGlobalList().addAll(
							mRenderer.getListCollisions());

					Set list = new HashSet<>();
					list.add(mRenderer.getCibleCoords());
					mRenderer.getAllPreviousCibleList().push(list);
					mRenderer.getAllPreviousList().push(
							mRenderer.getListCoords());

					mRenderer.setListCoords(mRenderer.getListCollisions());
					mRenderer.getGlobalList().addAll(
							mRenderer.getListCollisions());

					if (cibleTouchee) {
						mRenderer.getEnCoursCibleList().add(
								mRenderer.getCibleCoords());
						mRenderer.getGlobalList().add(
								mRenderer.getCibleCoords());
					}
					mRenderer.getEnCoursList().addAll(
							mRenderer.getListCollisions());
					if(!mRenderer.getGlobalList().isEmpty()){
						if (typeSelection.equals("dichotomie"))
							sortListsDichotomie();
						else
							sortListsEnProfondeur();
					}
					mRenderer.getListCollisionsDepart().clear();
					mRenderer.getListCollisionsDepart().addAll(
							mRenderer.getGlobalList());

					nbDivisionsScrollable = mRenderer.getListCollisionsDepart()
							.size() - 1;

					mRenderer.getCylindre().setVisible(false);
					mRenderer.setListCoords(mRenderer.getListCollisions());

					cibleTouchee = true;

					/**
					 * Log : Listage des <code>Sphere</code>s qui ont �t�
					 * s�lectionn�es.
					 */
					hashBuff = new HashMap<>();
					hashBuff.put("name", "ListOfDisplayedSphere");
					if (!mRenderer.getGlobalList().isEmpty())
						hashBuff.put("nb", ((Integer) mRenderer.getGlobalList()
								.size()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());

					if (mRenderer.getGlobalList().size() <= 1) {
						buttonBack.setEnabled(false);
						buttonFront.setEnabled(false);
					}

					ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
					HashMap<String, String> hashSpheres;
					for (Sphere sphere : mRenderer.getGlobalList()) {
						hashSpheres = new HashMap<String, String>();
						hashSpheres.put("name", "DisplayedSphere");
						hashSpheres.put("id", sphere.getId().toString());

						listSpheres.add(hashSpheres);
					}
					hashBuff.put("spheres", listSpheres);
					listLogs.add(hashBuff);

					buttonValidate.setVisibility(View.VISIBLE);
					buttonUndo.setVisibility(View.VISIBLE);
					buttonBack.setVisibility(View.VISIBLE);
					buttonFront.setVisibility(View.VISIBLE);

					if (!mRenderer.getGlobalList().isEmpty()) {
						List<Sphere> listArrayBack = new ArrayList<Sphere>(
								mRenderer.getGlobalList());
						Collections.sort(listArrayBack);
						Sphere sphereSelect = listArrayBack.get(0);

						/**
						 * Log : <code>Sphere</code> s�lectionn�e. Celle qui a
						 * le plus petit Z.
						 */
						hashBuff = new HashMap<String, String>();
						hashBuff.put("name", "SphereEvent");
						hashBuff.put("id", sphereSelect.getId().toString());
						hashBuff.put("type", "2");
						hashBuff.put(
								"t",
								((Long) Calendar.getInstance(
										TimeZone.getTimeZone("UTC"))
										.getTimeInMillis()).toString());
						listLogs.add(hashBuff);
					}
				}

				if (me.getAction() == MotionEvent.ACTION_POINTER_2_DOWN) {
					starting_distance = (float) Math.sqrt((Math.pow(
							(me.getX(0) - me.getX(1)), 2))
							+ (Math.pow((me.getY(0) - me.getY(1)), 2)));

					/** Log : D�placement de deux doigt simultann�ment . */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "4");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put("d", ((Float) starting_distance).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}

				if (me.getAction() == MotionEvent.ACTION_MOVE
						&& touchCount == 2) {

					float final_distance = (float) Math.sqrt((Math.pow(
							(me.getX(0) - me.getX(1)), 2))
							+ (Math.pow((me.getY(0) - me.getY(1)), 2)));
					float scale = mRenderer.getCylindre().getRadius()
							* (final_distance / starting_distance);

					/** Log : D�placement de deux doigt simultann�ment . */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "4");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put("d", ((Float) scale).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					if (scale > Cylinder.MIN_RADIUS
							&& scale < Cylinder.MAX_RADIUS) {
						mRenderer.getCylindre().setRadius(scale);

						/** Log : D�placement de deux doigt simultann�ment . */
						hashBuff = new HashMap<String, String>();
						hashBuff.put("name", "CylinderEvent");
						hashBuff.put("type", "3");
						hashBuff.put("x", ((Float) mRenderer.getCylindre()
								.getX()).toString());
						hashBuff.put("y", ((Float) mRenderer.getCylindre()
								.getY()).toString());
						hashBuff.put("radius", ((Float) mRenderer.getCylindre()
								.getRadius()).toString());
						hashBuff.put(
								"t",
								((Long) Calendar.getInstance(
										TimeZone.getTimeZone("UTC"))
										.getTimeInMillis()).toString());
						listLogs.add(hashBuff);
					}

					mRenderer
							.setListCollisions(mRenderer.getCylindre()
									.collateCylinder(
											(HashSet<Sphere>) mRenderer
													.getListCoords()));
					mRenderer.setCibleIsTouch(mRenderer.getCylindre()
							.isCollateCylinderAndCible(
									mRenderer.getCibleCoords()));

					/**
					 * Si la cible est touch�e on lance le son d'une
					 * notification du device.
					 */
					if (mRenderer.isCibleIsTouch()) {

						if (!cibleTouchee) {
							Uri notification = RingtoneManager
									.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
							Ringtone r = RingtoneManager.getRingtone(
									getApplicationContext(), notification);
							r.play();
							cibleTouchee = true;
						}
					} else {

						cibleTouchee = false;
					}
				}
				mGLSurfaceView.requestRender();

			} else {
				if (me.getAction() == MotionEvent.ACTION_DOWN) {

					/** Log : Pression du doigt sur l'�cran */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "1");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}

				if (me.getAction() == MotionEvent.ACTION_MOVE) {

					/** Log : D�placement du doigt sur l'�cran. */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "2");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}

				if (me.getAction() == MotionEvent.ACTION_UP) {

					/** Log : relachement du doigt de l'�cran. */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "TouchEvent");
					hashBuff.put("type", "3");
					hashBuff.put("x", ((Float) me.getX()).toString());
					hashBuff.put("y", ((Float) me.getY()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					float ypos, xpos;
					xpos = me.getX();
					ypos = me.getY();

					// On test si on est dans le cube
					if (ypos > (actionBarHeight + statusBarHeight)
							&& xpos < ((4.25f * (screen_width * 2)) / 5.5f)
							&& xpos > (((1.25f * (screen_width * 2)) / 5.5f))
							&& ypos < ((screen_heights * 2) - navigationBarHeight)) {
						// Cas d'une validation par toucher
						if (touchValidationIsChecked) {
							validationTouch(ypos, xpos);
						}
					}
				}

				/**
				 * Technique d'interaction : Scrolling
				 */
				if (typeSelection.equals("scroll")) {

					// Validation de la sphere s�lectionn�e
					// Zone : Bas Gauche
					// if (me.getAction() == MotionEvent.ACTION_UP) {
					// if (me.getX() <= screen_width
					// && me.getY() > screen_heights) {
					//
					// /** Log : Click sur le bouton fictif de validation. */
					// hashBuff = new HashMap<String, String>();
					// hashBuff.put("name", "KeyEvent");
					// hashBuff.put("code", "1");
					// hashBuff.put(
					// "t",
					// ((Long) Calendar.getInstance(
					// TimeZone.getTimeZone("UTC"))
					// .getTimeInMillis()).toString());
					// listLogs.add(hashBuff);
					//
					// validation();
					// }
					// }

					// Scrolling pour circuler dans l'espace sur l'axe des Z
					// Zone : Droite
					
					// Test si on est dans la partie droite de l'�cran
					if (me.getX() > (screen_width * 2)
							- ((1.25f * (screen_width * 2)) / 5.5f)) {

						Float height = (float) screen_heights * 2;

						Float ySelect = me.getY();
						Integer nbSphereRemoved = -(((int) ((nbDivisionsScrollable * ySelect) / height)) - nbDivisionsScrollable);

						if (zoneEnCours != nbSphereRemoved) {

							zoneEnCours = nbSphereRemoved;
							mRenderer.getAccessListLock().lock();
							try {

								mRenderer.getGlobalList().clear();
								mRenderer.getGlobalList().addAll(
										mRenderer.getListCollisionsDepart());

								List<Sphere> list = new ArrayList(
										mRenderer.getGlobalList());
								Collections.sort(list);

								for (int i = 0; i < nbSphereRemoved; i++) {
									Sphere iSphere = list.get(i);
									mRenderer.getGlobalList().remove(iSphere);
								}

								mRenderer.getListCoords().clear();
								mRenderer.getListCoords().addAll(
										mRenderer.getGlobalList());

								sortListsEnProfondeur();

								/** Log : Scrolling. */
								hashBuff = new HashMap<String, String>();
								hashBuff.put("name", "KeyEvent");
								hashBuff.put("code", "4");
								hashBuff.put(
										"t",
										((Long) Calendar.getInstance(
												TimeZone.getTimeZone("UTC"))
												.getTimeInMillis()).toString());
								listLogs.add(hashBuff);

								/**
								 * Log : Enum�ration de toutes les
								 * <code>Sphere</code>s encore visibles.
								 */
								hashBuff = new HashMap<>();
								hashBuff.put("name", "ListOfDisplayedSphere");
								if (!mRenderer.getGlobalList().isEmpty())
									hashBuff.put("nb", ((Integer) mRenderer
											.getGlobalList().size()).toString());
								hashBuff.put(
										"t",
										((Long) Calendar.getInstance(
												TimeZone.getTimeZone("UTC"))
												.getTimeInMillis()).toString());

								ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
								HashMap<String, String> hashSpheres;
								for (Sphere sphere : mRenderer.getGlobalList()) {
									hashSpheres = new HashMap<String, String>();
									hashSpheres.put("name", "DisplayedSphere");
									hashSpheres.put("id", sphere.getId()
											.toString());

									listSpheres.add(hashSpheres);
								}
								hashBuff.put("spheres", listSpheres);
								listLogs.add(hashBuff);

								if (!mRenderer.getGlobalList().isEmpty()) {
									List<Sphere> listArrayBack = new ArrayList<Sphere>(
											mRenderer.getGlobalList());
									Collections.sort(listArrayBack);
									Sphere sphereSelect = listArrayBack.get(0);

									/**
									 * Log : <code>Sphere</code> s�lectionn�e.
									 * Celle qui a le plus petit Z.
									 */
									hashBuff = new HashMap<String, String>();
									hashBuff.put("name", "SphereEvent");
									hashBuff.put("id", sphereSelect.getId()
											.toString());
									hashBuff.put("type", "2");
									hashBuff.put(
											"t",
											((Long) Calendar
													.getInstance(
															TimeZone.getTimeZone("UTC"))
													.getTimeInMillis())
													.toString());
									listLogs.add(hashBuff);
								}
								mGLSurfaceView.requestRender();
							} finally {
								mRenderer.getAccessListLock().unlock();
							}
						}
					}
				}

				// else {
				// /**
				// * Technique d'interaction : Dichotomie ou Circulation
				// */
				//
				// if (me.getAction() == MotionEvent.ACTION_UP) {

				// if (me.getX() <= screen_width
				// && me.getY() > screen_heights) {
				//
				// /** Log : Click sur le bouton fictif de validation.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "KeyEvent");
				// hashBuff.put("code", "1");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar.getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis()).toString());
				// listLogs.add(hashBuff);
				//
				// validation();
				//
				// }

				// if (me.getX() > screen_width
				// && me.getY() > screen_heights
				// && frontIsSelectable) {
				// mRenderer.getAccessListLock().lock();
				// try {
				//
				// if (typeSelection.equals("dichotomie")) {
				//
				// nbClickRecherche++;
				// clickFront++;
				//
				// mRenderer.getAllPreviousCibleList().push(
				// mRenderer.getEnCoursCibleList());
				// mRenderer.getAllPreviousList().push(
				// mRenderer.getEnCoursList());
				//
				// undoIsSelectable = true;
				//
				// HashSet<Sphere> cibles = new HashSet<Sphere>();
				// HashSet<Sphere> spheres = new HashSet<Sphere>();
				// for (Sphere aSphere : mRenderer
				// .getFrontList()) {
				// if (mRenderer.getEnCoursCibleList()
				// .contains(aSphere))
				// cibles.add(aSphere);
				// else
				// spheres.add(aSphere);
				// }
				//
				// mRenderer.setListCoords(spheres);
				// mRenderer.setListCollisions(spheres);
				//
				// mRenderer.setEnCoursCibleList(cibles);
				// mRenderer.setEnCoursList(spheres);
				//
				// mRenderer.getGlobalList().removeAll(
				// mRenderer.getBackList());
				// sortListsDichotomie();
				//
				// if (mRenderer.getGlobalList().size() <= 1) {
				// backIsSelectable = false;
				// frontIsSelectable = false;
				// }
				//
				// /**
				// * Log : Click sur le bouton fictif en haut
				// * � droite.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "KeyEvent");
				// hashBuff.put("code", "2");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar
				// .getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis())
				// .toString());
				// listLogs.add(hashBuff);
				//
				// /**
				// * Log : Enum�ration de toutes les
				// * <code>Sphere</code>s encore visibles.
				// */
				// hashBuff = new HashMap<>();
				// hashBuff.put("name",
				// "ListOfDisplayedSphere");
				// if (!mRenderer.getGlobalList().isEmpty())
				// hashBuff.put("nb", ((Integer) mRenderer
				// .getGlobalList().size())
				// .toString());
				// hashBuff.put(
				// "t",
				// ((Long) Calendar
				// .getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis())
				// .toString());
				//
				// ArrayList<HashMap<String, String>> listSpheres = new
				// ArrayList<HashMap<String, String>>();
				// HashMap<String, String> hashSpheres;
				// for (Sphere sphere : mRenderer
				// .getGlobalList()) {
				// hashSpheres = new HashMap<String, String>();
				// hashSpheres.put("name",
				// "DisplayedSphere");
				// hashSpheres.put("id", sphere.getId()
				// .toString());
				//
				// listSpheres.add(hashSpheres);
				// }
				// hashBuff.put("spheres", listSpheres);
				// listLogs.add(hashBuff);
				// }
				// if (!mRenderer.getGlobalList().isEmpty()) {
				// List<Sphere> listArrayBack = new ArrayList<Sphere>(
				// mRenderer.getGlobalList());
				// Collections.sort(listArrayBack);
				// Sphere sphereSelect = listArrayBack.get(0);
				//
				// /**
				// * Log : <code>Sphere</code> s�lectionn�e.
				// * Celle qui a le plus petit Z.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "SphereEvent");
				// hashBuff.put("id", sphereSelect.getId()
				// .toString());
				// hashBuff.put("type", "2");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar
				// .getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis())
				// .toString());
				// listLogs.add(hashBuff);
				// }
				// mGLSurfaceView.requestRender();
				// } finally {
				// mRenderer.getAccessListLock().unlock();
				// }
				// }
				// if (me.getX() <= screen_width
				// && me.getY() <= screen_heights
				// && undoIsSelectable) {
				// mRenderer.getAccessListLock().lock();
				// try {
				//
				// clickUndo++;
				// if (nbClickRecherche == 1)
				// undoIsSelectable = false;
				//
				// if (mRenderer.getGlobalList().size() <= 1) {
				// backIsSelectable = true;
				// frontIsSelectable = true;
				//
				// }
				// nbClickRecherche--;
				//
				// mRenderer.setEnCoursCibleList(mRenderer
				// .getAllPreviousCibleList().pop());
				// mRenderer.setEnCoursList(mRenderer
				// .getAllPreviousList().pop());
				//
				// mRenderer.setListCoords(mRenderer
				// .getEnCoursList());
				// mRenderer.setListCollisions(mRenderer
				// .getEnCoursList());
				//
				// mRenderer.getGlobalList().addAll(
				// mRenderer.getEnCoursCibleList());
				// mRenderer.getGlobalList().addAll(
				// mRenderer.getEnCoursList());
				//
				// if (typeSelection.equals("dichotomie"))
				// sortListsDichotomie();
				// else
				// sortListsEnProfondeur();
				//
				// /**
				// * Log : Click sur le bouton fictif undo en haut
				// * � gauche.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "KeyEvent");
				// hashBuff.put("code", "0");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar.getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis()).toString());
				// listLogs.add(hashBuff);
				//
				// /**
				// * Log : Enum�ration de toutes les
				// * <code>Sphere</code>s encore visibles.
				// */
				// hashBuff = new HashMap<>();
				// hashBuff.put("name", "ListOfDisplayedSphere");
				// if (!mRenderer.getGlobalList().isEmpty())
				// hashBuff.put("nb", ((Integer) mRenderer
				// .getGlobalList().size()).toString());
				// hashBuff.put(
				// "t",
				// ((Long) Calendar.getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis()).toString());
				//
				// ArrayList<HashMap<String, String>> listSpheres = new
				// ArrayList<HashMap<String, String>>();
				// HashMap<String, String> hashSpheres;
				// for (Sphere sphere : mRenderer.getGlobalList()) {
				// hashSpheres = new HashMap<String, String>();
				// hashSpheres.put("name", "DisplayedSphere");
				// hashSpheres.put("id", sphere.getId()
				// .toString());
				//
				// listSpheres.add(hashSpheres);
				// }
				// hashBuff.put("spheres", listSpheres);
				// listLogs.add(hashBuff);
				//
				// if (!mRenderer.getGlobalList().isEmpty()) {
				// List<Sphere> listArrayBack = new ArrayList<Sphere>(
				// mRenderer.getGlobalList());
				// Collections.sort(listArrayBack);
				// Sphere sphereSelect = listArrayBack.get(0);
				//
				// /**
				// * Log : <code>Sphere</code> s�lectionn�e.
				// * Celle qui a le plus petit Z.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "SphereEvent");
				// hashBuff.put("id", sphereSelect.getId()
				// .toString());
				// hashBuff.put("type", "2");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar
				// .getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis())
				// .toString());
				// listLogs.add(hashBuff);
				// }
				// mGLSurfaceView.requestRender();
				// } finally {
				// mRenderer.getAccessListLock().unlock();
				// }
				// }
				// if (me.getX() > screen_width
				// && me.getY() <= screen_heights
				// && backIsSelectable) {
				// mRenderer.getAccessListLock().lock();
				// try {
				//
				// nbClickRecherche++;
				// clickBack++;
				//
				// mRenderer.getAllPreviousCibleList().push(
				// mRenderer.getEnCoursCibleList());
				// mRenderer.getAllPreviousList().push(
				// mRenderer.getEnCoursList());
				//
				// undoIsSelectable = true;
				//
				// HashSet<Sphere> cibles = new HashSet<Sphere>();
				// HashSet<Sphere> spheres = new HashSet<Sphere>();
				// for (Sphere aSphere : mRenderer.getBackList()) {
				// if (mRenderer.getEnCoursCibleList()
				// .contains(aSphere))
				// cibles.add(aSphere);
				// else
				// spheres.add(aSphere);
				// }
				//
				// mRenderer.setListCoords(spheres);
				// mRenderer.setListCollisions(spheres);
				//
				// mRenderer.setEnCoursCibleList(cibles);
				// mRenderer.setEnCoursList(spheres);
				//
				// if (typeSelection.equals("dichotomie")) {
				// mRenderer.getGlobalList().removeAll(
				// mRenderer.getFrontList());
				// sortListsDichotomie();
				// } else {
				// List<Sphere> list = new ArrayList(
				// mRenderer.getGlobalList());
				// Collections.sort(list);
				// Sphere firstSphere = list.get(0);
				// mRenderer.getGlobalList().remove(
				// firstSphere);
				// sortListsEnProfondeur();
				// }
				//
				// if (mRenderer.getGlobalList().size() <= 1) {
				// backIsSelectable = false;
				// frontIsSelectable = false;
				//
				// }
				//
				// /**
				// * Log : Click sur le bouton fictif en bas �
				// * droite.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "KeyEvent");
				// hashBuff.put("code", "3");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar.getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis()).toString());
				// listLogs.add(hashBuff);
				//
				// /**
				// * Log : Enum�ration de toutes les
				// * <code>Sphere</code>s encore visibles.
				// */
				// hashBuff = new HashMap<>();
				// hashBuff.put("name", "ListOfDisplayedSphere");
				// if (!mRenderer.getGlobalList().isEmpty())
				// hashBuff.put("nb", ((Integer) mRenderer
				// .getGlobalList().size()).toString());
				// hashBuff.put(
				// "t",
				// ((Long) Calendar.getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis()).toString());
				//
				// ArrayList<HashMap<String, String>> listSpheres = new
				// ArrayList<HashMap<String, String>>();
				// HashMap<String, String> hashSpheres;
				// for (Sphere sphere : mRenderer.getGlobalList()) {
				// hashSpheres = new HashMap<String, String>();
				// hashSpheres.put("name", "DisplayedSphere");
				// hashSpheres.put("id", sphere.getId()
				// .toString());
				//
				// listSpheres.add(hashSpheres);
				// }
				// hashBuff.put("spheres", listSpheres);
				// listLogs.add(hashBuff);
				//
				// if (!mRenderer.getGlobalList().isEmpty()) {
				// List<Sphere> listArrayBack = new ArrayList<Sphere>(
				// mRenderer.getGlobalList());
				// Collections.sort(listArrayBack);
				// Sphere sphereSelect = listArrayBack.get(0);
				//
				// /**
				// * Log : <code>Sphere</code> s�lectionn�e.
				// * Celle qui a le plus petit Z.
				// */
				// hashBuff = new HashMap<String, String>();
				// hashBuff.put("name", "SphereEvent");
				// hashBuff.put("id", sphereSelect.getId()
				// .toString());
				// hashBuff.put("type", "2");
				// hashBuff.put(
				// "t",
				// ((Long) Calendar
				// .getInstance(
				// TimeZone.getTimeZone("UTC"))
				// .getTimeInMillis())
				// .toString());
				// listLogs.add(hashBuff);
				// }
				// mGLSurfaceView.requestRender();
				// } finally {
				// mRenderer.getAccessListLock().unlock();
				// }
				// }
				// }
				// }
			}
		}
		return true;
	}

	@Override
	public void onClick(View v) {

		/**
		 * Le bouton front permet de ne garder que la partie avant de la dichotomie
		 */
		if (v.equals(buttonFront)) {
			nbClickRecherche++;

			mRenderer.getAccessListLock().lock();
			try {
				mRenderer.getAllPreviousCibleList().push(
						mRenderer.getEnCoursCibleList());
				mRenderer.getAllPreviousList().push(mRenderer.getEnCoursList());

				buttonUndo.setEnabled(true);

				HashSet<Sphere> cibles = new HashSet<Sphere>();
				HashSet<Sphere> spheres = new HashSet<Sphere>();
				for (Sphere aSphere : mRenderer.getFrontList()) {
					if (mRenderer.getEnCoursCibleList().contains(aSphere))
						cibles.add(aSphere);
					else
						spheres.add(aSphere);
				}

				mRenderer.setListCoords(spheres);
				mRenderer.setListCollisions(spheres);

				mRenderer.setEnCoursCibleList(cibles);
				mRenderer.setEnCoursList(spheres);

				mRenderer.getGlobalList().removeAll(mRenderer.getBackList());
				sortListsDichotomie();

				if (mRenderer.getGlobalList().size() <= 1) {
					buttonBack.setEnabled(false);
					buttonFront.setEnabled(false);
				}
				/**
				 * Log : Click sur le bouton fictif en haut � droite.
				 */
				hashBuff = new HashMap<String, String>();
				hashBuff.put("name", "KeyEvent");
				hashBuff.put("code", "2");
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());
				listLogs.add(hashBuff);

				/**
				 * Log : Enum�ration de toutes les <code>Sphere</code>s encore
				 * visibles.
				 */
				hashBuff = new HashMap<>();
				hashBuff.put("name", "ListOfDisplayedSphere");
				if (!mRenderer.getGlobalList().isEmpty())
					hashBuff.put("nb", ((Integer) mRenderer.getGlobalList()
							.size()).toString());
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());

				ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
				HashMap<String, String> hashSpheres;
				for (Sphere sphere : mRenderer.getGlobalList()) {
					hashSpheres = new HashMap<String, String>();
					hashSpheres.put("name", "DisplayedSphere");
					hashSpheres.put("id", sphere.getId().toString());

					listSpheres.add(hashSpheres);
				}
				hashBuff.put("spheres", listSpheres);
				listLogs.add(hashBuff);

				if (!mRenderer.getGlobalList().isEmpty()) {
					List<Sphere> listArrayBack = new ArrayList<Sphere>(
							mRenderer.getGlobalList());
					Collections.sort(listArrayBack);
					Sphere sphereSelect = listArrayBack.get(0);

					/**
					 * Log : <code>Sphere</code> s�lectionn�e. Celle qui a le
					 * plus petit Z.
					 */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "SphereEvent");
					hashBuff.put("id", sphereSelect.getId().toString());
					hashBuff.put("type", "2");
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}
				mGLSurfaceView.requestRender();
			} finally {
				mRenderer.getAccessListLock().unlock();
			}
		}

		/**
		 * Le bouton back permet :
		 * 	- de ne garder que la partie arriere dans le cas de la dichotomie 
		 * 	- de supprimer le premier �l�ment dans le cas de la circulation 
		 */
		if (v.equals(buttonBack)) {

			mRenderer.getAccessListLock().lock();
			try {
				nbClickRecherche++;
				mRenderer.getAllPreviousCibleList().push(
						mRenderer.getEnCoursCibleList());
				mRenderer.getAllPreviousList().push(mRenderer.getEnCoursList());

				buttonUndo.setEnabled(true);

				HashSet<Sphere> cibles = new HashSet<Sphere>();
				HashSet<Sphere> spheres = new HashSet<Sphere>();
				for (Sphere aSphere : mRenderer.getBackList()) {
					if (mRenderer.getEnCoursCibleList().contains(aSphere))
						cibles.add(aSphere);
					else
						spheres.add(aSphere);
				}

				mRenderer.setListCoords(spheres);
				mRenderer.setListCollisions(spheres);

				mRenderer.setEnCoursCibleList(cibles);
				mRenderer.setEnCoursList(spheres);

				if (typeSelection.equals("dichotomie")) {
					mRenderer.getGlobalList().removeAll(
							mRenderer.getFrontList());
					sortListsDichotomie();
				} else {
					List<Sphere> list = new ArrayList(mRenderer.getGlobalList());
					Collections.sort(list);
					Sphere firstSphere = list.get(0);
					mRenderer.getGlobalList().remove(firstSphere);
					sortListsEnProfondeur();
				}

				if (mRenderer.getGlobalList().size() <= 1) {
					buttonBack.setEnabled(false);
					buttonFront.setEnabled(false);
				}

				/**
				 * Log : Click sur le bouton fictif en bas � droite.
				 */
				hashBuff = new HashMap<String, String>();
				hashBuff.put("name", "KeyEvent");
				hashBuff.put("code", "3");
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());
				listLogs.add(hashBuff);

				/**
				 * Log : Enum�ration de toutes les <code>Sphere</code>s encore
				 * visibles.
				 */
				hashBuff = new HashMap<>();
				hashBuff.put("name", "ListOfDisplayedSphere");
				if (!mRenderer.getGlobalList().isEmpty())
					hashBuff.put("nb", ((Integer) mRenderer.getGlobalList()
							.size()).toString());
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());

				ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
				HashMap<String, String> hashSpheres;
				for (Sphere sphere : mRenderer.getGlobalList()) {
					hashSpheres = new HashMap<String, String>();
					hashSpheres.put("name", "DisplayedSphere");
					hashSpheres.put("id", sphere.getId().toString());

					listSpheres.add(hashSpheres);
				}
				hashBuff.put("spheres", listSpheres);
				listLogs.add(hashBuff);

				if (!mRenderer.getGlobalList().isEmpty()) {
					List<Sphere> listArrayBack = new ArrayList<Sphere>(
							mRenderer.getGlobalList());
					Collections.sort(listArrayBack);
					Sphere sphereSelect = listArrayBack.get(0);

					/**
					 * Log : <code>Sphere</code> s�lectionn�e. Celle qui a le
					 * plus petit Z.
					 */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "SphereEvent");
					hashBuff.put("id", sphereSelect.getId().toString());
					hashBuff.put("type", "2");
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);
				}
				mGLSurfaceView.requestRender();
			} finally {
				mRenderer.getAccessListLock().unlock();
			}
		}

		/**
		 * Le bouton undo permet :
		 * 	- de ne reselectionner une zone du cube si on l'utilise au maximum 
		 * 	- de revenir � l'�tat pr�c�dent dans les TI
		 */
		if (v.equals(buttonUndo)) {

			mRenderer.getAccessListLock().lock();
			try {
				if (nbClickRecherche == 1) {
					buttonUndo.setEnabled(false);

					nbClickRecherche--;

					initButton();

					slideTouchee = false;

					mRenderer.setListCoords(mRenderer.getAllPreviousList()
							.pop());
					mRenderer.setListCollisions(mRenderer
							.getListCollisionsDepart());

					/**
					 * Log : Click sur le bouton fictif undo en haut � gauche.
					 */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "KeyEvent");
					hashBuff.put("code", "0");
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					mRenderer.getGlobalList().clear();
					mRenderer.getGlobalList().addAll(mRenderer.getListCoords());
					mRenderer.getGlobalList().add(mRenderer.getCibleCoords());

					/**
					 * Log : Enum�ration de toutes les <code>Sphere</code>s
					 * encore visibles.
					 */
					hashBuff = new HashMap<>();
					hashBuff.put("name", "ListOfDisplayedSphere");
					if (!mRenderer.getGlobalList().isEmpty())
						hashBuff.put("nb", ((Integer) mRenderer.getGlobalList()
								.size()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());

					ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
					HashMap<String, String> hashSpheres;
					for (Sphere sphere : mRenderer.getGlobalList()) {
						hashSpheres = new HashMap<String, String>();
						hashSpheres.put("name", "DisplayedSphere");
						hashSpheres.put("id", sphere.getId().toString());

						listSpheres.add(hashSpheres);
					}
					hashBuff.put("spheres", listSpheres);
					listLogs.add(hashBuff);

					mRenderer.setEnCoursCibleList(new HashSet<Sphere>());
					mRenderer.setEnCoursList(new HashSet<Sphere>());

					mRenderer.setAllPreviousList(new Stack<Set<Sphere>>());
					mRenderer.setAllPreviousCibleList(new Stack<Set<Sphere>>());

					mRenderer.setGlobalList(new HashSet<Sphere>());
					mRenderer.setBackList(new HashSet<Sphere>());
					mRenderer.setFrontList(new HashSet<Sphere>());

					mRenderer.getCylindre().setVisible(true);

					mGLSurfaceView.requestRender();

				} else {
					if (nbClickRecherche == 1)
						buttonUndo.setEnabled(false);

					if (mRenderer.getGlobalList().size() == 1) {
						buttonBack.setEnabled(true);
						if (typeSelection.equals("dichotomie"))
							buttonFront.setEnabled(true);
					}
					nbClickRecherche--;

					mRenderer.setEnCoursCibleList(mRenderer
							.getAllPreviousCibleList().pop());
					mRenderer.setEnCoursList(mRenderer.getAllPreviousList()
							.pop());

					mRenderer.setListCoords(mRenderer.getEnCoursList());
					mRenderer.setListCollisions(mRenderer.getEnCoursList());

					mRenderer.getGlobalList().addAll(
							mRenderer.getEnCoursCibleList());
					mRenderer.getGlobalList()
							.addAll(mRenderer.getEnCoursList());

					if (typeSelection.equals("dichotomie"))
						sortListsDichotomie();
					else
						sortListsEnProfondeur();

					/**
					 * Log : Click sur le bouton fictif undo en haut � gauche.
					 */
					hashBuff = new HashMap<String, String>();
					hashBuff.put("name", "KeyEvent");
					hashBuff.put("code", "0");
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());
					listLogs.add(hashBuff);

					/**
					 * Log : Enum�ration de toutes les <code>Sphere</code>s
					 * encore visibles.
					 */
					hashBuff = new HashMap<>();
					hashBuff.put("name", "ListOfDisplayedSphere");
					if (!mRenderer.getGlobalList().isEmpty())
						hashBuff.put("nb", ((Integer) mRenderer.getGlobalList()
								.size()).toString());
					hashBuff.put(
							"t",
							((Long) Calendar.getInstance(
									TimeZone.getTimeZone("UTC"))
									.getTimeInMillis()).toString());

					ArrayList<HashMap<String, String>> listSpheres = new ArrayList<HashMap<String, String>>();
					HashMap<String, String> hashSpheres;
					for (Sphere sphere : mRenderer.getGlobalList()) {
						hashSpheres = new HashMap<String, String>();
						hashSpheres.put("name", "DisplayedSphere");
						hashSpheres.put("id", sphere.getId().toString());

						listSpheres.add(hashSpheres);
					}
					hashBuff.put("spheres", listSpheres);
					listLogs.add(hashBuff);

					if (!mRenderer.getGlobalList().isEmpty()) {
						List<Sphere> listArrayBack = new ArrayList<Sphere>(
								mRenderer.getGlobalList());
						Collections.sort(listArrayBack);
						Sphere sphereSelect = listArrayBack.get(0);

						/**
						 * Log : <code>Sphere</code> s�lectionn�e. Celle qui a
						 * le plus petit Z.
						 */
						hashBuff = new HashMap<String, String>();
						hashBuff.put("name", "SphereEvent");
						hashBuff.put("id", sphereSelect.getId().toString());
						hashBuff.put("type", "2");
						hashBuff.put(
								"t",
								((Long) Calendar.getInstance(
										TimeZone.getTimeZone("UTC"))
										.getTimeInMillis()).toString());
						listLogs.add(hashBuff);
					}
					mGLSurfaceView.requestRender();
				}
			} finally {
				mRenderer.getAccessListLock().unlock();
			}

		}

		/**
		 * Le bouton validate permet :
		 * 	- de choisir la premiere sphere (celle qui a le plus petit Z)
		 */
		if (v.equals(buttonValidate)) {
			hashBuff = new HashMap<String, String>();
			hashBuff.put("name", "KeyEvent");
			hashBuff.put("code", "1");
			hashBuff.put("t",
					((Long) Calendar.getInstance(TimeZone.getTimeZone("UTC"))
							.getTimeInMillis()).toString());
			listLogs.add(hashBuff);

			validation();
		}

		mGLSurfaceView.requestRender();
	}

	/**
	 * Initialisation de tous les boutons, utilis� :
	 *  - pour les undos 
	 *  - et apr�s chaque validations
	 */
	private void initButton() {
		buttonFront.setVisibility(View.INVISIBLE);
		buttonBack.setVisibility(View.INVISIBLE);
		buttonUndo.setVisibility(View.INVISIBLE);
		buttonValidate.setVisibility(View.INVISIBLE);

		buttonUndo.setEnabled(true);

		if (typeSelection.equals("scroll"))
			buttonBack.setEnabled(false);
		else
			buttonBack.setEnabled(true);

		if (!typeSelection.equals("dichotomie"))
			buttonFront.setEnabled(false);
		else
			buttonFront.setEnabled(true);

		if (touchValidationIsChecked)
			buttonValidate.setEnabled(false);
		else
			buttonValidate.setEnabled(true);

	}

	@Override
	protected void onResume() {
		// The activity must call the GL surface view's onResume() on activity
		// onResume().
		super.onResume();
		mGLSurfaceView.onResume();
	}

	@Override
	protected void onPause() {
		// The activity must call the GL surface view's onPause() on activity
		// onPause().
		super.onPause();
		mGLSurfaceView.onPause();
	}

	/**
	 * Validation de la sphere s�lectionn�e et cr�ation du test suivant dans le cas d'une validation par boutons
	 */
	@SuppressWarnings("unchecked")
	private void validation() {
		mRenderer.setCreated(false);
		if (!mRenderer.getGlobalList().isEmpty()) {
			List<Sphere> listArrayBack = new ArrayList<Sphere>(
					mRenderer.getGlobalList());
			Collections.sort(listArrayBack);
			Sphere sphereSelect = listArrayBack.get(0);

			/**
			 * Log : <code>Sphere</code> Valid�e. Celle qui a le plus petit Z.
			 */
			hashBuff = new HashMap<String, String>();
			hashBuff.put("name", "SphereEvent");
			hashBuff.put("id", sphereSelect.getId().toString());
			hashBuff.put("type", "3");
			hashBuff.put("t",
					((Long) Calendar.getInstance(TimeZone.getTimeZone("UTC"))
							.getTimeInMillis()).toString());
			listLogs.add(hashBuff);				
			Toast.makeText(getApplicationContext(), "Vous avez s�lectionn� la sphere " + sphereSelect.getId().toString()+".", Toast.LENGTH_SHORT).show();	
		} else {

			/**
			 * Log : <code>Sphere</code> Valid�e. Celle qui a le plus petit Z.
			 */
			hashBuff = new HashMap<String, String>();
			hashBuff.put("name", "SphereEvent");
			hashBuff.put("id", "-1");
			hashBuff.put("type", "3");
			hashBuff.put("t",
					((Long) Calendar.getInstance(TimeZone.getTimeZone("UTC"))
							.getTimeInMillis()).toString());
			listLogs.add(hashBuff);
			Toast.makeText(getApplicationContext(), "Vous n'avez s�lectionn� aucune sphere.", Toast.LENGTH_SHORT).show();
		}
		ArrayList<HashMap> list = new ArrayList<HashMap>();
		list.addAll(listLogs);
		listTask.add(list);
		initLogs();

		if (mRenderer.getListZones().size() != 0) {
			mRenderer.createTest();

		} else {
			dialog.show();
			dialog.setCanceledOnTouchOutside(false);
			xmlLogs.write(listTask);
		}

		initButton();

		cibleTouchee = false;
		firstTouch = true;
		slideTouchee = false;
		nbClickRecherche = 0;
	}

	/**
	 *  Validation de la sphere s�lectionn�e et cr�ation du test suivant dans le cas d'une validation par toucher
	 * @param ypos
	 * @param xpos
	 */
	@SuppressWarnings("unchecked")
	private void validationTouch(float ypos, float xpos) {
		mRenderer.setCreated(false);
		if (!mRenderer.getGlobalList().isEmpty()) {
			float x, y;
			Sphere sphereMinZ = new Sphere(0, 0, 2f, 0);
			sphereMinZ.setId(-1);
			for (Sphere sphere : mRenderer.getGlobalList()) {
				int heightScreen = screen_heights * 2;

				y = (((ypos
						- ((0.12f * (heightScreen - navigationBarHeight - (actionBarHeight + statusBarHeight))) / 3) - (actionBarHeight + statusBarHeight)) / (heightScreen
						- navigationBarHeight - (actionBarHeight + statusBarHeight))) * -3f) + 1.5f;

				int widthScreen = screen_width * 2;
				x = (((xpos - ((1.25f * widthScreen) / 5.5f)) / (widthScreen - (((1.25f * widthScreen) / 5.5f) * 2))) * -(mRenderer
						.getCube().getCote() * 2f))
						+ mRenderer.getCube().getCote();

				if (sphere.sphereIsTouch(x, y)) {
					System.out.println("Touchee : " + sphere.getId());
					if (sphere.getZ() < sphereMinZ.getZ())
						sphereMinZ = sphere;
				}
			}

			if (sphereMinZ.getId() != -1) {

				/**
				 * Log : <code>Sphere</code> Valid�e. Celle qui a le plus petit
				 * Z.
				 */
				hashBuff = new HashMap<String, String>();
				hashBuff.put("name", "SphereEvent");
				hashBuff.put("id", sphereMinZ.getId().toString());
				hashBuff.put("type", "3");
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());
				listLogs.add(hashBuff);
				Toast.makeText(getApplicationContext(), "Vous avez s�lectionn� la sphere " + sphereMinZ.getId().toString()+".", Toast.LENGTH_SHORT).show();
			} else {

				/**
				 * Log : <code>Sphere</code> Valid�e. Celle qui a le plus petit
				 * Z.
				 */
				hashBuff = new HashMap<String, String>();
				hashBuff.put("name", "SphereEvent");
				hashBuff.put("id", "-1");
				hashBuff.put("type", "3");
				hashBuff.put(
						"t",
						((Long) Calendar.getInstance(
								TimeZone.getTimeZone("UTC")).getTimeInMillis())
								.toString());
				listLogs.add(hashBuff);
				Toast.makeText(getApplicationContext(), "Vous n'avez s�lectionn� aucune sphere.", Toast.LENGTH_SHORT).show();
			}
			ArrayList<HashMap> list = new ArrayList<HashMap>();
			list.addAll(listLogs);
			listTask.add(list);
			initLogs();

			if (mRenderer.getListZones().size() != 0) {
				mRenderer.createTest();

			} else {
				dialog.show();
				dialog.setCanceledOnTouchOutside(false);
				xmlLogs.write(listTask);
			}

			initButton();

			cibleTouchee = false;

			slideTouchee = false;
			nbClickRecherche = 0;
		} else {

			/**
			 * Log : <code>Sphere</code> Valid�e. Aucune.
			 */
			hashBuff = new HashMap<String, String>();
			hashBuff.put("name", "SphereEvent");
			hashBuff.put("id", "-1");
			hashBuff.put("type", "3");
			hashBuff.put("t",
					((Long) Calendar.getInstance(TimeZone.getTimeZone("UTC"))
							.getTimeInMillis()).toString());
			listLogs.add(hashBuff);
			ArrayList<HashMap> list = new ArrayList<HashMap>();
			list.addAll(listLogs);
			listTask.add(list);
			initLogs();
			Toast.makeText(getApplicationContext(), "Vous n'avez s�lectionn� aucune sphere.", Toast.LENGTH_SHORT).show();

			if (mRenderer.getListZones().size() != 0) {
				mRenderer.createTest();

			} else {
				dialog.show();
				dialog.setCanceledOnTouchOutside(false);
				xmlLogs.write(listTask);
			}

			initButton();

			cibleTouchee = false;

			slideTouchee = false;
			nbClickRecherche = 0;
		}
		firstTouch = true;
	}

	private void initLogs() {
		touchCount = 0;
		nbClickRecherche = 0;
		listLogs.clear();
	}

	/**
	 * Trie des <code>Sphere</code>s seon leurs positions et leur status
	 */
	public void sortListsDichotomie() {
		int i = 0;
		List<Sphere> list = new ArrayList(mRenderer.getGlobalList());
		Collections.sort(list);

		mRenderer.setFrontList(new HashSet<Sphere>());
		mRenderer.setBackList(new HashSet<Sphere>());

		for (Sphere aSphere : list) {

			if (i < list.size() / 2) {
				mRenderer.getFrontList().add(aSphere);
			} else {
				mRenderer.getBackList().add(aSphere);
			}
			i++;
		}
	}

	/**
	 * Trie des <code>Sphere</code>s seon leurs positions et leur status
	 */
	public void sortListsEnProfondeur() {
		int i = 0;
		List<Sphere> list = new ArrayList(mRenderer.getGlobalList());

		List<Sphere> listArrayBack = new ArrayList<Sphere>(list);
		Collections.sort(listArrayBack);
		listArrayBack.remove(0);
		mRenderer.setBackList(new HashSet<Sphere>());
		mRenderer.getBackList().addAll(listArrayBack);

		mRenderer.setFrontList(new HashSet<Sphere>());
	}

	/** Getters & Setters */
	public PrismGLSurfaceView getmGLSurfaceView() {
		return mGLSurfaceView;
	}

	public void setmGLSurfaceView(PrismGLSurfaceView mGLSurfaceView) {
		this.mGLSurfaceView = mGLSurfaceView;
	}

	public int getScreen_heights() {
		return screen_heights;
	}

	public void setScreen_heights(int screen_heights) {
		this.screen_heights = screen_heights;
	}

	public int getActionBarHeight() {
		return actionBarHeight;
	}

	public void setActionBarHeight(int actionBarHeight) {
		this.actionBarHeight = actionBarHeight;
	}

	public int getNavigationBarHeight() {
		return navigationBarHeight;
	}

	public void setNavigationBarHeight(int navigationBarHeight) {
		this.navigationBarHeight = navigationBarHeight;
	}

	public int getStatusBarHeight() {
		return statusBarHeight;
	}

	public void setStatusBarHeight(int statusBarHeight) {
		this.statusBarHeight = statusBarHeight;
	}

	public int getScreen_width() {
		return screen_width;
	}

	public void setScreen_width(int screen_width) {
		this.screen_width = screen_width;
	}

	public boolean isShowTopView() {
		return showTopView;
	}

	public void setShowTopView(boolean showTop) {
		showTopView = showTop;
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		this.finish();
	}
}