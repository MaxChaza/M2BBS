package com.example.prism3;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.HashSet;
import java.util.Iterator;

import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.FloatMath;

import com.example.prism3.utils.Light;
import com.example.prism3.utils.MatrixPrism;
import com.example.prism3.utils.ModelPrism;
import com.threed.jpct.Object3D;
import com.threed.jpct.SimpleVector;

public class Cylinder {

	/** Mesure utile au calcul de construction du <code>Cylinder</code> */
	private static final float TWO_PI = (float) (2 * Math.PI);

	/** How many bytes per float. */
	private final int mBytesPerFloat = 4;

	private static int fanTriangleCount;
	private static int stripTriangleCount;

	private static FloatBuffer bottomVerticesBuf;
	private static FloatBuffer sideVerticesBuf;

	// The normal is used in light calculations and is a vector which points
	// orthogonal to the plane of the surface. For a cube model, the normals
	// should be orthogonal to the points of each face.
	private static FloatBuffer sideNormalsBuf;
	private static FloatBuffer bottomNormalsBuf;

	// Texture coordinate data.
	// Because images have a Y axis pointing downward (values increase as
	// you move down the image) while
	// OpenGL has a Y axis pointing upward, we adjust for that here by
	// flipping the Y axis.
	// What's more is that the texture coordinates are the same for every
	// face.
	private static FloatBuffer mSideTextureCoordinates;
	private static FloatBuffer mBottomTextureCoordinates;

	private float radius, originalRadius, length, x, y, z;
	private boolean isVisible;
	private boolean isCreated;
	
	public static final float MAX_RADIUS = 0.6f;	
	public static final float MIN_RADIUS = 0.05f;
	/**
	 * Constructeur du <code>Cylinder</code> Cr�e les positions et l'orientation
	 * du <code>Cylinder</code>
	 * 
	 * @param xAx
	 * @param yAx
	 * @param zAx
	 * @param rayon
	 * @param longueur
	 */
	public Cylinder(float xAx, float yAx, float zAx, float rayon, float longueur) {
		x = xAx;
		y = yAx;
		z = zAx;
		radius = rayon;
		originalRadius = rayon;
		length = longueur;
		int sides = 20;

		isVisible = true;
		isCreated = false;

		double dTheta = TWO_PI / sides;

		float[] sideVertices = new float[(sides + 1) * 6];
		float[] sideNormals = new float[(sides + 1) * 6];
		float[] sideTexture = new float[((sides + 1) * 6) * 2 / 3];
		for (int i = 0; i < sideTexture.length; i++) {
			sideTexture[i] = 0;
		}

		int sideVidx = 0;
		int sideNidx = 0;

		float[] bottomVertices = new float[(sides + 2) * 3];
		float[] bottomNormals = new float[(sides + 2) * 3];
		float[] bottomTexture = new float[((sides + 2) * 3) * 2 / 3];
		for (int i = 0; i < bottomTexture.length; i++) {
			bottomTexture[i] = 0;
		}
		int capVidx = 3;
		int capNidx = 3;

		bottomVertices[0] = 0f;
		bottomVertices[1] = 0f;
		bottomVertices[2] = -.5f;

		bottomNormals[0] = 1f;
		bottomNormals[1] = 1f;
		bottomNormals[2] = 1f;

		for (float theta = 0; theta <= (TWO_PI + dTheta); theta += dTheta) {

			sideVertices[sideVidx++] = FloatMath.cos(theta); // X

			sideVertices[sideVidx++] = FloatMath.sin(theta); // Y

			sideVertices[sideVidx++] = 0.5f; // Z

			sideVertices[sideVidx++] = FloatMath.cos(theta); // X

			sideVertices[sideVidx++] = FloatMath.sin(theta); // Y

			sideVertices[sideVidx++] = -0.5f; // Z

			float forceLumiere = 7f;

			sideNormals[sideNidx++] = FloatMath.cos(theta) * forceLumiere; // X

			sideNormals[sideNidx++] = FloatMath.sin(theta) * forceLumiere; // Y

			sideNormals[sideNidx++] = 0f; // Z

			sideNormals[sideNidx++] = FloatMath.cos(theta) * forceLumiere; // X

			sideNormals[sideNidx++] = FloatMath.sin(theta) * forceLumiere; // Y

			sideNormals[sideNidx++] = 0f; // Z

			// X
			bottomVertices[capVidx++] = FloatMath.cos(TWO_PI - theta);
			// Y
			bottomVertices[capVidx++] = FloatMath.sin(TWO_PI - theta);
			// Z
			bottomVertices[capVidx++] = -0.5f;

			// Normals
			bottomNormals[capNidx++] = 0f;
			bottomNormals[capNidx++] = 0f;
			bottomNormals[capNidx++] = -1f;

		}

		stripTriangleCount = sideVertices.length / 3;
		fanTriangleCount = sides + 2;

		// Initialize the buffers.
		sideVerticesBuf = ByteBuffer
				.allocateDirect(sideVertices.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		sideVerticesBuf.put(sideVertices).position(0);

		sideNormalsBuf = ByteBuffer
				.allocateDirect(sideNormals.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		sideNormalsBuf.put(sideNormals).position(0);

		mSideTextureCoordinates = ByteBuffer
				.allocateDirect(sideTexture.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		mSideTextureCoordinates.put(sideTexture).position(0);

		bottomVerticesBuf = ByteBuffer
				.allocateDirect(bottomVertices.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		bottomVerticesBuf.put(bottomVertices).position(0);

		bottomNormalsBuf = ByteBuffer
				.allocateDirect(bottomNormals.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		bottomNormalsBuf.put(bottomNormals).position(0);

		mBottomTextureCoordinates = ByteBuffer
				.allocateDirect(bottomTexture.length * mBytesPerFloat)
				.order(ByteOrder.nativeOrder()).asFloatBuffer();
		mBottomTextureCoordinates.put(bottomTexture).position(0);

	}

	/** Pour dessiner le <code>Cylinder</code> on dessine le cot� puis l'avant*/ 
	public void drawCylinder(MatrixPrism matrix, Light light, ModelPrism model,
			int texture) {

		// Set the active texture unit to texture unit 0.
		GLES20.glActiveTexture(GLES20.GL_TEXTURE0);

		// Bind the texture to this unit.
		GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);

		// Tell the texture uniform sampler to use this texture in the shader by
		// binding to texture unit 0.
		GLES20.glUniform1i(model.getmTextureUniformHandle(), 0);

		drawSide(matrix, light, model, texture);
		drawBottom(matrix, light, model, texture);
	}

	/** Dessine le c�t� du <code>Cylinder</code>*/
	public void drawSide(MatrixPrism matrix, Light light, ModelPrism model,
			int texture) {
		// Pass in the position information
		sideVerticesBuf.position(0);
		GLES20.glVertexAttribPointer(model.getmPositionHandle(),
				ModelPrism.mPositionDataSize, GLES20.GL_FLOAT, false, 0,
				sideVerticesBuf);

		// Pass in the normal information
		sideNormalsBuf.position(0);
		GLES20.glVertexAttribPointer(model.getmNormalHandle(),
				ModelPrism.mNormalDataSize, GLES20.GL_FLOAT, false, 0,
				sideNormalsBuf);

		mSideTextureCoordinates.position(0);
		GLES20.glVertexAttribPointer(model.getmTextureCoordinateHandle(),
				ModelPrism.mTextureCoordinateDataSize, GLES20.GL_FLOAT, false,
				0, mSideTextureCoordinates);
		// This multiplies the view matrix by the model matrix, and stores the
		// result in the MVP matrix
		// (which currently contains model * view).
		Matrix.multiplyMM(matrix.getmMVPMatrix(), 0, matrix.getmViewMatrix(),
				0, matrix.getmModelMatrix(), 0);

		// Pass in the modelview matrix.
		GLES20.glUniformMatrix4fv(model.getmMVMatrixHandle(), 1, false,
				matrix.getmMVPMatrix(), 0);

		// This multiplies the modelview matrix by the projection matrix, and
		// stores the result in the MVP matrix
		// (which now contains model * view * projection).
		Matrix.multiplyMM(matrix.getmTemporaryMatrix(), 0,
				matrix.getmProjectionMatrix(), 0, matrix.getmMVPMatrix(), 0);
		System.arraycopy(matrix.getmTemporaryMatrix(), 0,
				matrix.getmMVPMatrix(), 0, 16);

		// Pass in the combined matrix.
		GLES20.glUniformMatrix4fv(model.getmMVPMatrixHandle(), 1, false,
				matrix.getmMVPMatrix(), 0);

		// Pass in the light position in eye space.
		GLES20.glUniform3f(light.getmLightPosHandle(),
				light.getmLightPosInEyeSpace(0),
				light.getmLightPosInEyeSpace(1),
				light.getmLightPosInEyeSpace(2));

		GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, stripTriangleCount);
	}

	/** Dessine le fond du <code>Cylinder</code>*/
	public void drawBottom(MatrixPrism matrix, Light light, ModelPrism model,
			int texture) {
		// Pass in the position information
		bottomVerticesBuf.position(0);
		GLES20.glVertexAttribPointer(model.getmPositionHandle(),
				ModelPrism.mPositionDataSize, GLES20.GL_FLOAT, false, 0,
				bottomVerticesBuf);

		// Pass in the normal information
		bottomNormalsBuf.position(0);
		GLES20.glVertexAttribPointer(model.getmNormalHandle(),
				ModelPrism.mNormalDataSize, GLES20.GL_FLOAT, false, 0,
				bottomNormalsBuf);

		mBottomTextureCoordinates.position(0);
		GLES20.glVertexAttribPointer(model.getmTextureCoordinateHandle(),
				ModelPrism.mTextureCoordinateDataSize, GLES20.GL_FLOAT, false,
				0, mBottomTextureCoordinates);

		// This multiplies the view matrix by the model matrix, and stores the
		// result in the MVP matrix
		// (which currently contains model * view).
		Matrix.multiplyMM(matrix.getmMVPMatrix(), 0, matrix.getmViewMatrix(),
				0, matrix.getmModelMatrix(), 0);

		// Pass in the modelview matrix.
		GLES20.glUniformMatrix4fv(model.getmMVMatrixHandle(), 1, false,
				matrix.getmMVPMatrix(), 0);

		// This multiplies the modelview matrix by the projection matrix, and
		// stores the result in the MVP matrix
		// (which now contains model * view * projection).
		Matrix.multiplyMM(matrix.getmTemporaryMatrix(), 0,
				matrix.getmProjectionMatrix(), 0, matrix.getmMVPMatrix(), 0);
		System.arraycopy(matrix.getmTemporaryMatrix(), 0,
				matrix.getmMVPMatrix(), 0, 16);

		// Pass in the combined matrix.
		GLES20.glUniformMatrix4fv(model.getmMVPMatrixHandle(), 1, false,
				matrix.getmMVPMatrix(), 0);

		// Pass in the light position in eye space.
		GLES20.glUniform3f(light.getmLightPosHandle(),
				light.getmLightPosInEyeSpace(0),
				light.getmLightPosInEyeSpace(1),
				light.getmLightPosInEyeSpace(2));

		GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, fanTriangleCount);

	}

	/**
	 * Retourne la liste des <code>Sphere</code> travers�es par le <code>Cylinder</code>
	 * @param listEntrante
	 * @return HashSet<Sphere>
	 */
	public HashSet<Sphere> collateCylinder(HashSet<Sphere> listEntrante) {
		HashSet<Sphere> listSortante = new HashSet<>();
		for (Sphere sphere : listEntrante) {
			if (Math.sqrt(Math.pow((this.x - sphere.getX()), 2)
					+ Math.pow((this.y - sphere.getY()), 2)) <= this.radius
					+ sphere.getRayon()) {
				listSortante.add(sphere);
			}
		}
		return listSortante;
	}

	/**
	 * Retourne vrai si <code>Sphere</code> cible est travers�e par le <code>Cylinder</code>
	 * @param cible
	 * @return boolean
	 */
	public boolean isCollateCylinderAndCible(Sphere cible) {
		return Math.sqrt(Math.pow((this.x - cible.getX()), 2)
				+ Math.pow((this.y - cible.getY()), 2)) <= this.radius
				+ cible.getRayon();
	}

	/** Getters & setters*/
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getZ() {
		return z;
	}

	public void setZ(float z) {
		this.z = z;
	}
	
	public boolean isVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}

	public boolean isCreated() {
		return isCreated;
	}

	public void setCreated(boolean isCreated) {
		this.isCreated = isCreated;
	}

	public void setX(float x2) {
		x = x2;
	}

	public void setY(float y2) {
		y = y2;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getOriginalRadius() {
		return originalRadius;
	}
}
